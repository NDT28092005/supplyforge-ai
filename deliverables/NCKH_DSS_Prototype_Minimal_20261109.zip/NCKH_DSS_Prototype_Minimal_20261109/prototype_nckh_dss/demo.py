#!/usr/bin/env python3
"""Build a small, auditable DSS review prototype from frozen NCKH artefacts.

This is a research demonstration, not a live inventory system.  It consumes
recorded Online Retail II experiment evidence and makes the decision-time/
future-outcome boundary explicit in its JSON and HTML outputs.
"""

from __future__ import annotations

import argparse
import hashlib
import html
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_EXPERIMENT_DIR = ROOT / "reports_NCKH" / "nckh_online_retail_multiclass"
DEFAULT_OUTPUT_DIR = Path(__file__).resolve().parent / "output"
DEFAULT_RAW_SOURCE = ROOT / "online_retail_II.xlsx"
HIGH_RISK_CLASSES = {"CRITICAL", "HIGH_RISK"}

REQUIRED_ARTIFACTS = {
    "selected_config": "selected_config.json",
    "profile": "selected/dataset_profile.json",
    "labels": "selected/label_definition.json",
    "metrics": "selected/metrics.json",
    "predictions": "selected/test_predictions.csv",
    "snapshots": "selected/snapshots.parquet",
    "global_shap": "selected/shap_global_importance.csv",
}

PREDICTION_COLUMNS = {
    "sku",
    "cutoff_date",
    "risk_class",
    "future_qty",
    "lightgbm_prob_CRITICAL",
    "lightgbm_prob_HIGH_RISK",
    "lightgbm_prob_MEDIUM_RISK",
    "lightgbm_prob_LOW_RISK",
    "lightgbm_prediction_name",
}

SNAPSHOT_COLUMNS = {
    "sku",
    "cutoff_date",
    "sales_qty_7d",
    "sales_qty_28d",
    "sales_qty_90d",
    "zero_rate_7d",
    "zero_rate_28d",
    "active_days_28d",
    "days_since_last_sale",
    "velocity_trend_28d_vs_previous_56d",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create an Online Retail II research DSS review dossier."
    )
    parser.add_argument(
        "--experiment-dir",
        type=Path,
        default=DEFAULT_EXPERIMENT_DIR,
        help="Directory containing the frozen NCKH multiclass experiment artefacts.",
    )
    parser.add_argument(
        "--raw-source",
        type=Path,
        default=DEFAULT_RAW_SOURCE,
        help="Original workbook used only for source-checksum provenance.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help="Directory for generated HTML and JSON; it is created if necessary.",
    )
    parser.add_argument(
        "--cutoff",
        default="latest",
        help="Held-out cutoff date in YYYY-MM-DD format, or 'latest'.",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=6,
        help="Number of highest-ranked review candidates to display (1-20).",
    )
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require_artifacts(experiment_dir: Path) -> dict[str, Path]:
    paths = {key: experiment_dir / relative for key, relative in REQUIRED_ARTIFACTS.items()}
    missing = [str(path) for path in paths.values() if not path.is_file()]
    if missing:
        raise FileNotFoundError("Missing required experiment artefacts:\n- " + "\n- ".join(missing))
    return paths


def source_provenance(profile: dict[str, Any], raw_source: Path) -> dict[str, Any]:
    expected_hash = str(profile.get("source_sha256") or "")
    provenance: dict[str, Any] = {
        "source_file": str(profile.get("source_file") or raw_source),
        "raw_source_path": str(raw_source),
        "expected_sha256": expected_hash,
        "status": "SOURCE_NOT_CHECKED",
    }
    if raw_source.is_file():
        actual_hash = sha256_file(raw_source)
        provenance["actual_sha256"] = actual_hash
        provenance["status"] = "VERIFIED" if actual_hash == expected_hash else "CHECKSUM_MISMATCH"
    else:
        provenance["status"] = "SOURCE_FILE_NOT_FOUND"
    return provenance


def validate_config(selected_config: dict[str, Any], label_policy: dict[str, Any]) -> None:
    if selected_config.get("selected_horizon_days") != 28:
        raise ValueError("Prototype accepts only the selected 28-day NCKH configuration.")
    if selected_config.get("selected_model") != "lightgbm":
        raise ValueError("Prototype expects the frozen LightGBM selected model.")
    if label_policy.get("positive_future_qty_q25") != 9.0 or label_policy.get("positive_future_qty_q50") != 38.0:
        raise ValueError("Unexpected label thresholds; expected the frozen 9/38 policy.")


def review_band(score: float) -> str:
    """Presentation-only queue band, deliberately separate from a risk label."""
    if score >= 0.85:
        return "Ưu tiên rà soát rất cao"
    if score >= 0.65:
        return "Rà soát ưu tiên"
    return "Theo dõi trong queue"


def percentage(value: float) -> str:
    return f"{value * 100:.1f}%"


def number(value: float | int) -> str:
    return f"{float(value):,.0f}".replace(",", ".")


def retrospective_alignment(predicted_class: str, actual_class: str) -> str:
    """Describe retrospective label agreement without changing the queue score."""
    if predicted_class == actual_class:
        return "Khớp lớp chi tiết và nhóm rủi ro cao"
    if predicted_class in HIGH_RISK_CLASSES and actual_class in HIGH_RISK_CLASSES:
        return "Sai lớp chi tiết; đúng nhóm rủi ro cao"
    return "Không khớp nhóm rủi ro cao"


def signal_evidence(row: pd.Series) -> list[dict[str, str]]:
    zero_7 = int(round(float(row["zero_rate_7d"]) * 7))
    zero_28 = int(round(float(row["zero_rate_28d"]) * 28))
    trend = float(row["velocity_trend_28d_vs_previous_56d"])
    trend_text = "không có mẫu tham chiếu dương" if trend == 0 else f"{trend:.2f} lần"
    return [
        {
            "name": "Bán bằng 0 trong 7 ngày gần nhất",
            "value": f"{zero_7}/7 ngày",
            "detail": "Tín hiệu lịch sử tại cutoff; không phải giải thích nguyên nhân.",
        },
        {
            "name": "Hoạt động bán trong 28 ngày",
            "value": f"{number(row['sales_qty_28d'])} đơn vị · {zero_28}/28 ngày không bán",
            "detail": f"{number(row['active_days_28d'])} ngày có giao dịch dương.",
        },
        {
            "name": "Độ mới của lần bán gần nhất",
            "value": f"{number(row['days_since_last_sale'])} ngày trước cutoff",
            "detail": f"Tổng lượng bán 90 ngày là {number(row['sales_qty_90d'])} đơn vị.",
        },
        {
            "name": "Xu hướng vận tốc bán",
            "value": trend_text,
            "detail": "So sánh vận tốc 28 ngày gần nhất với 56 ngày trước đó.",
        },
    ]


def build_alert_queue(predictions: pd.DataFrame, snapshots: pd.DataFrame, cutoff: str, limit: int) -> tuple[list[dict[str, Any]], dict[str, int]]:
    if not 1 <= limit <= 20:
        raise ValueError("--limit must be between 1 and 20.")

    prediction_slice = predictions.loc[predictions["cutoff_date"].eq(cutoff)].copy()
    snapshot_slice = snapshots.loc[
        snapshots["cutoff_date"].dt.strftime("%Y-%m-%d").eq(cutoff)
    ].copy()
    snapshot_slice["cutoff_date"] = snapshot_slice["cutoff_date"].dt.strftime("%Y-%m-%d")
    if prediction_slice.empty or snapshot_slice.empty:
        raise ValueError(f"No compatible selected-test evidence found for cutoff {cutoff}.")

    decision_columns = sorted(SNAPSHOT_COLUMNS)
    merged = prediction_slice.merge(
        snapshot_slice[decision_columns], on=["sku", "cutoff_date"], how="inner", validate="one_to_one"
    )
    merged["review_score"] = (
        merged["lightgbm_prob_CRITICAL"] + merged["lightgbm_prob_HIGH_RISK"]
    )
    eligible = merged.loc[merged["lightgbm_prediction_name"].isin(HIGH_RISK_CLASSES)].copy()
    ranked = eligible.sort_values(["review_score", "sku"], ascending=[False, True]).head(limit)

    alerts: list[dict[str, Any]] = []
    for rank, (_, row) in enumerate(ranked.iterrows(), start=1):
        predicted_class = str(row["lightgbm_prediction_name"])
        actual_class = str(row["risk_class"])
        critical_probability = float(row["lightgbm_prob_CRITICAL"])
        high_probability = float(row["lightgbm_prob_HIGH_RISK"])
        class_probabilities = {
            "CRITICAL": round(critical_probability, 6),
            "HIGH_RISK": round(high_probability, 6),
            "MEDIUM_RISK": round(float(row["lightgbm_prob_MEDIUM_RISK"]), 6),
            "LOW_RISK": round(float(row["lightgbm_prob_LOW_RISK"]), 6),
        }
        alerts.append(
            {
                "rank": rank,
                "sku": str(row["sku"]),
                "cutoff_date": cutoff,
                "review_score": round(float(row["review_score"]), 6),
                "review_band": review_band(float(row["review_score"])),
                "predicted_class": predicted_class,
                "class_probabilities": class_probabilities,
                "high_risk_score_breakdown": {
                    "critical_probability": round(critical_probability, 6),
                    "high_risk_probability": round(high_probability, 6),
                    "formula": "P(CRITICAL) + P(HIGH_RISK)",
                    "interpretation": "Điểm queue cho nhóm rủi ro cao, không phải xác suất của riêng lớp CRITICAL.",
                },
                "decision_time_evidence": signal_evidence(row),
                "matured_outcome_after_28_days": {
                    "actual_class": actual_class,
                    "future_quantity": float(row["future_qty"]),
                    "agreement": retrospective_alignment(predicted_class, actual_class),
                    "disclosure": "Chỉ dùng để đánh giá hồi cứu sau khi cửa sổ 28 ngày đã đóng; không phải input của điểm dự đoán.",
                },
            }
        )
    return alerts, {"snapshot_count": len(merged), "review_candidate_count": len(eligible)}


def top_global_signals(shap_importance: pd.DataFrame) -> list[dict[str, Any]]:
    required = {"feature", "mean_abs_shap_mean"}
    if missing := required.difference(shap_importance.columns):
        raise ValueError(f"SHAP artefact missing columns: {sorted(missing)}")
    records: list[dict[str, Any]] = []
    for _, row in shap_importance.nlargest(5, "mean_abs_shap_mean").iterrows():
        records.append(
            {
                "feature": str(row["feature"]),
                "mean_abs_shap": round(float(row["mean_abs_shap_mean"]), 6),
            }
        )
    return records


def choose_cutoff(predictions: pd.DataFrame, requested: str) -> str:
    available = sorted(predictions["cutoff_date"].astype(str).unique().tolist())
    if not available:
        raise ValueError("No cutoff values in selected test predictions.")
    if requested == "latest":
        return available[-1]
    if requested not in available:
        raise ValueError(f"Cutoff must be one of {available}; received {requested}.")
    return requested


def build_demo_payload(experiment_dir: Path, raw_source: Path, cutoff_request: str, limit: int) -> dict[str, Any]:
    paths = require_artifacts(experiment_dir)
    selected_config = read_json(paths["selected_config"])
    profile = read_json(paths["profile"])
    labels = read_json(paths["labels"])
    metrics = read_json(paths["metrics"])
    validate_config(selected_config, labels)

    predictions = pd.read_csv(paths["predictions"])
    snapshots = pd.read_parquet(paths["snapshots"])
    shap_importance = pd.read_csv(paths["global_shap"])
    if missing := PREDICTION_COLUMNS.difference(predictions.columns):
        raise ValueError(f"Prediction artefact missing columns: {sorted(missing)}")
    if missing := SNAPSHOT_COLUMNS.difference(snapshots.columns):
        raise ValueError(f"Snapshot artefact missing columns: {sorted(missing)}")

    predictions["cutoff_date"] = pd.to_datetime(predictions["cutoff_date"]).dt.strftime("%Y-%m-%d")
    snapshots["cutoff_date"] = pd.to_datetime(snapshots["cutoff_date"])
    cutoff = choose_cutoff(predictions, cutoff_request)
    alerts, queue_counts = build_alert_queue(predictions, snapshots, cutoff, limit)
    if not alerts:
        raise ValueError("No CRITICAL/HIGH_RISK review candidates at this cutoff.")

    lgbm_test = metrics["models"]["lightgbm"]["test"]
    cleaning = profile["cleaning_audit"]
    return {
        "prototype": {
            "name": "NCKH DSS Review Prototype",
            "version": "1.0",
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
            "research_only": True,
        },
        "interpretation_boundary": "Demo ưu tiên rà soát rủi ro doanh số thấp trong tương lai. Không suy ra tồn kho dư, lỗi thời, thiệt hại tài chính hoặc nguyên nhân của doanh số thấp.",
        "provenance": {
            "experiment_dir": str(experiment_dir.resolve()),
            "raw_source": source_provenance(profile, raw_source),
            "selected_configuration": {
                "horizon_days": selected_config["selected_horizon_days"],
                "model": selected_config["selected_model"],
                "lookback_days": labels["config"]["lookback_days"],
                "cutoff_frequency_days": labels["config"]["cutoff_frequency_days"],
                "random_state": labels["config"]["random_state"],
                "q25": labels["positive_future_qty_q25"],
                "q50": labels["positive_future_qty_q50"],
            },
            "input_audit": {
                "raw_transaction_rows": cleaning["raw_rows"],
                "retained_transaction_rows": cleaning["retained_transaction_rows"],
                "retained_skus": cleaning["retained_skus"],
                "eligible_sku_cutoff_snapshots": profile["snapshot_rows"],
            },
        },
        "decision_context": {
            "cutoff_date": cutoff,
            "history_window_days": labels["config"]["lookback_days"],
            "outcome_horizon_days": labels["config"]["horizon_days"],
            "queue_counts": queue_counts,
            "score_definition": "P(CRITICAL) + P(HIGH_RISK) from frozen LightGBM predictions.",
            "decision_time_exclusions": labels["future_fields_excluded_from_features"],
        },
        "experiment_result": {
            "test_macro_f1": lgbm_test["macro_f1"],
            "test_balanced_accuracy": lgbm_test["balanced_accuracy"],
            "test_high_risk_recall": lgbm_test["high_risk_group_recall"],
            "test_high_risk_average_precision": lgbm_test["high_risk_pr_auc"],
        },
        "global_model_signals": top_global_signals(shap_importance),
        "alerts": alerts,
    }


def esc(value: Any) -> str:
    return html.escape(str(value), quote=True)


def render_evidence(items: list[dict[str, str]]) -> str:
    return "".join(
        f"<li><strong>{esc(item['name'])}</strong><span>{esc(item['value'])}</span><small>{esc(item['detail'])}</small></li>"
        for item in items
    )


def render_class_probabilities(probabilities: dict[str, float]) -> str:
    rows = "".join(
        f"<li class=\"prob-{class_name.lower()}\"><span>P({esc(class_name)})</span><strong>{percentage(value)}</strong></li>"
        for class_name, value in probabilities.items()
    )
    total = sum(probabilities.values())
    return f"""
      <section class="class-probabilities" aria-label="Xác suất dự đoán của bốn lớp">
        <p>Xác suất của bốn lớp</p>
        <ul>{rows}</ul>
        <small>Tổng bốn xác suất = {percentage(total)}; sai khác nhỏ có thể xuất hiện do làm tròn.</small>
      </section>
    """


def render_alerts(alerts: list[dict[str, Any]]) -> str:
    rendered: list[str] = []
    for alert in alerts:
        outcome = alert["matured_outcome_after_28_days"]
        score_breakdown = alert["high_risk_score_breakdown"]
        class_probabilities = alert["class_probabilities"]
        open_attr = " open" if alert["rank"] == 1 else ""
        rendered.append(
            f"""
            <details class="alert"{open_attr}>
              <summary>
                <span class="rank">{alert['rank']:02d}</span>
                <span class="sku">SKU {esc(alert['sku'])}</span>
                <span class="band {esc(alert['predicted_class'].lower())}">{esc(alert['review_band'])}</span>
                <span class="score">{percentage(alert['review_score'])}</span>
              </summary>
              <div class="alert-body">
                <div class="prediction-row">
                  <div><span>Lớp dự đoán tại cutoff</span><strong>{esc(alert['predicted_class'])}</strong></div>
                </div>
                <section class="score-explainer" aria-label="Công thức điểm nhóm rủi ro cao">
                  <p>Điểm nhóm rủi ro cao</p>
                  <div class="score-equation">
                    <span><small>P(CRITICAL)</small><strong>{percentage(score_breakdown['critical_probability'])}</strong></span>
                    <b class="operator">+</b>
                    <span><small>P(HIGH_RISK)</small><strong>{percentage(score_breakdown['high_risk_probability'])}</strong></span>
                    <b class="operator">=</b>
                    <span class="total"><small>Điểm queue</small><strong>{percentage(alert['review_score'])}</strong></span>
                  </div>
                  <small>{esc(score_breakdown['interpretation'])} Các số hiển thị được làm tròn.</small>
                </section>
                {render_class_probabilities(class_probabilities)}
                <p class="evidence-intro">Bằng chứng dưới đây chỉ dùng giao dịch đến hết cutoff. Đây là các fact để rà soát, không phải kết luận nguyên nhân.</p>
                <ul class="evidence-list">{render_evidence(alert['decision_time_evidence'])}</ul>
                <details class="matured">
                  <summary>Outcome sau khi cửa sổ 28 ngày đã đóng</summary>
                  <div class="matured-status">{esc(outcome['agreement'])}</div>
                  <p><strong>{esc(outcome['actual_class'])}</strong> · {number(outcome['future_quantity'])} đơn vị bán thực tế.</p>
                  <small>{esc(outcome['disclosure'])}</small>
                </details>
              </div>
            </details>
            """
        )
    return "\n".join(rendered)


def render_html(payload: dict[str, Any]) -> str:
    provenance = payload["provenance"]
    context = payload["decision_context"]
    result = payload["experiment_result"]
    audit = provenance["input_audit"]
    raw = provenance["raw_source"]
    global_signals = "".join(
        f"<li><span>{esc(item['feature'])}</span><strong>{item['mean_abs_shap']:.3f}</strong></li>"
        for item in payload["global_model_signals"]
    )
    alerts = render_alerts(payload["alerts"])
    return f"""<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>NCKH DSS Review Prototype</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400&family=IBM+Plex+Mono:wght@400;500;600;700&family=Lexend:wght@500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {{
      --paper: #f3f6f1; --surface: #ffffff; --ink: #15363b; --muted: #597074;
      --line: #c8d4d1; --lake: #2b7280; --lake-pale: #dcecf0;
      --critical: #9c2f35; --critical-pale: #f8e8e9; --high: #a86421;
      --high-pale: #f7ede1; --shadow: rgba(21, 54, 59, .08);
    }}
    * {{ box-sizing: border-box; }}
    body {{ margin: 0; color: var(--ink); background: var(--paper); font-family: "Be Vietnam Pro", system-ui, -apple-system, sans-serif; line-height: 1.55; }}
    main {{ max-width: 1240px; margin: 0 auto; padding: 28px 22px 48px; }}
    .masthead {{ border-bottom: 3px solid var(--ink); padding: 8px 0 22px; display: grid; grid-template-columns: 1fr auto; gap: 24px; align-items: end; }}
    h1 {{ font-family: "Lexend", "Be Vietnam Pro", sans-serif; margin: 0; font-size: clamp(2rem, 5vw, 3.7rem); font-weight: 700; letter-spacing: -.055em; line-height: 1.08; max-width: 15ch; }}
    .kicker, .provenance, .step-no {{ font-family: "IBM Plex Mono", ui-monospace, monospace; font-size: .72rem; letter-spacing: .025em; color: var(--muted); }}
    .run-tag {{ border: 1px solid var(--lake); padding: 8px 11px; color: var(--lake); font-family: "IBM Plex Mono", ui-monospace, monospace; font-size: .76rem; white-space: nowrap; }}
    .boundary {{ margin: 24px 0; padding: 15px 18px; border-left: 5px solid var(--high); background: #fffdf9; max-width: 80ch; }}
    .flow {{ display: grid; grid-template-columns: repeat(4, 1fr); border: 1px solid var(--line); background: var(--surface); margin-bottom: 28px; }}
    .flow-step {{ min-height: 136px; padding: 17px; border-right: 1px solid var(--line); position: relative; }}
    .flow-step:last-child {{ border-right: 0; }}
    .flow-step:not(:last-child)::after {{ content: "→"; position: absolute; right: -9px; top: 50%; transform: translateY(-50%); z-index: 2; color: var(--lake); background: var(--surface); font-size: 1.25rem; }}
    .flow-step strong {{ display: block; margin-top: 8px; font-size: 1rem; }}
    .flow-step p {{ margin: 6px 0 0; font-size: .86rem; color: var(--muted); }}
    .dossier {{ display: grid; grid-template-columns: minmax(320px, .88fr) minmax(0, 1.45fr); gap: 24px; align-items: start; }}
    .panel {{ background: var(--surface); border: 1px solid var(--line); }}
    .panel-head {{ padding: 18px 20px; border-bottom: 1px solid var(--line); display: flex; justify-content: space-between; gap: 14px; align-items: baseline; }}
    h2 {{ font-family: "Lexend", "Be Vietnam Pro", sans-serif; font-size: 1.35rem; font-weight: 650; margin: 0; letter-spacing: -.035em; }}
    .panel-head p {{ margin: 0; color: var(--muted); font-size: .88rem; }}
    .queue {{ padding: 8px; }}
    details.alert {{ border-bottom: 1px solid var(--line); }}
    details.alert:last-child {{ border-bottom: 0; }}
    summary {{ cursor: pointer; list-style: none; }}
    summary::-webkit-details-marker {{ display: none; }}
    .alert > summary {{ display: grid; grid-template-columns: 34px 1fr auto; align-items: center; gap: 10px; padding: 14px 10px; }}
    .rank {{ color: var(--lake); font-family: "IBM Plex Mono", ui-monospace, monospace; font-size: 1rem; font-weight: 600; }}
    .sku {{ font-weight: 700; }}
    .band {{ grid-column: 2; font-size: .79rem; color: var(--muted); }}
    .band.critical {{ color: var(--critical); }} .band.high_risk {{ color: var(--high); }}
    .score {{ color: var(--lake); font-family: "IBM Plex Mono", ui-monospace, monospace; font-variant-numeric: tabular-nums; font-weight: 700; grid-column: 3; grid-row: 1 / span 2; }}
    .alert[open] > summary {{ background: var(--lake-pale); }}
    .alert-body {{ padding: 14px 20px 20px 54px; }}
    .prediction-row {{ display: grid; grid-template-columns: 1fr 1fr; gap: 12px; padding-bottom: 14px; border-bottom: 1px dashed var(--line); }}
    .prediction-row span, .evidence-list small, .matured small {{ display: block; color: var(--muted); font-size: .82rem; }}
    .score-explainer {{ margin: 15px 0 17px; padding: 13px 14px; border-left: 3px solid var(--lake); background: #edf6f7; }}
    .score-explainer > p {{ margin: 0 0 9px; color: var(--ink); font-weight: 700; font-size: .9rem; }}
    .score-explainer > small {{ color: var(--muted); font-size: .77rem; line-height: 1.4; }}
    .score-equation {{ display: flex; align-items: center; gap: 8px; margin-bottom: 9px; font-family: "IBM Plex Mono", ui-monospace, monospace; }}
    .score-equation span {{ display: grid; gap: 1px; min-width: 0; }}
    .score-equation small {{ color: var(--muted); font-family: "Be Vietnam Pro", system-ui, sans-serif; font-size: .68rem; white-space: nowrap; }}
    .score-equation strong {{ color: var(--lake); font-size: 1rem; font-variant-numeric: tabular-nums; }}
    .score-equation .operator {{ color: var(--muted); font-size: 1rem; }}
    .score-equation .total {{ margin-left: 1px; }} .score-equation .total strong {{ color: var(--ink); }}
    .class-probabilities {{ margin: 0 0 17px; padding: 13px 14px; border: 1px solid #d4e0de; background: #fbfcfa; }}
    .class-probabilities > p {{ margin: 0 0 9px; font-weight: 700; font-size: .9rem; }}
    .class-probabilities > small {{ color: var(--muted); font-size: .77rem; }}
    .class-probabilities ul {{ list-style: none; display: grid; grid-template-columns: 1fr 1fr; gap: 6px 16px; padding: 0; margin: 0 0 8px; }}
    .class-probabilities li {{ display: flex; justify-content: space-between; padding-bottom: 3px; border-bottom: 1px solid #e4ebe8; font-family: "IBM Plex Mono", ui-monospace, monospace; font-size: .82rem; }}
    .class-probabilities .prob-critical strong {{ color: var(--critical); }} .class-probabilities .prob-high_risk strong {{ color: var(--high); }}
    .evidence-intro {{ color: var(--muted); font-size: .9rem; }}
    .evidence-list {{ padding: 0; list-style: none; }}
    .evidence-list li {{ padding: 10px 0; border-bottom: 1px solid #e6ece9; }}
    .evidence-list strong {{ display: block; }} .evidence-list span {{ color: var(--lake); font-weight: 700; }}
    .matured {{ margin-top: 17px; padding: 12px 14px; background: #fbf4f0; border-left: 3px solid var(--high); }}
    .matured summary {{ font-weight: 700; }} .matured p {{ margin: 10px 0 4px; }}
    .matured-status {{ display: inline-block; margin-top: 10px; padding: 3px 7px; color: #7b4b18; background: #fff4df; font-size: .78rem; font-weight: 700; }}
    .facts {{ padding: 20px; }}
    .facts-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 0; border-top: 1px solid var(--line); border-left: 1px solid var(--line); }}
    .fact {{ padding: 15px; border-right: 1px solid var(--line); border-bottom: 1px solid var(--line); }}
    .fact span {{ color: var(--muted); display: block; font-size: .8rem; }} .fact strong {{ font-family: "IBM Plex Mono", ui-monospace, monospace; font-size: 1.16rem; font-variant-numeric: tabular-nums; }}
    .global {{ margin-top: 20px; border-top: 1px solid var(--line); padding-top: 18px; }}
    .global h3 {{ font-family: "Lexend", "Be Vietnam Pro", sans-serif; font-size: 1rem; font-weight: 600; letter-spacing: -.02em; margin: 0 0 8px; }}
    .global ol {{ list-style: none; padding: 0; margin: 0; }}
    .global li {{ display: flex; justify-content: space-between; border-bottom: 1px solid #e6ece9; padding: 8px 0; }}
    .footnote {{ margin-top: 24px; color: var(--muted); font-size: .83rem; max-width: 92ch; }}
    @media (max-width: 820px) {{
      main {{ padding: 20px 14px 36px; }} .masthead {{ grid-template-columns: 1fr; }}
      .run-tag {{ width: fit-content; }} .flow {{ grid-template-columns: 1fr; }}
      .flow-step {{ min-height: 0; border-right: 0; border-bottom: 1px solid var(--line); }}
      .flow-step:not(:last-child)::after {{ content: "↓"; right: 16px; top: auto; bottom: -13px; }}
      .dossier {{ grid-template-columns: 1fr; }} .alert-body {{ padding-left: 20px; }}
      .score-equation {{ flex-wrap: wrap; }}
      .class-probabilities ul {{ grid-template-columns: 1fr; }}
    }}
    @media (prefers-reduced-motion: reduce) {{ * {{ scroll-behavior: auto; }} }}
  </style>
</head>
<body>
  <main>
    <header class="masthead">
      <div><p class="kicker">Prototype nghiên cứu · Online Retail II · luồng DSS có thể kiểm tra</p><h1>Hồ sơ rà soát rủi ro doanh số</h1></div>
      <div class="run-tag">Nguồn dữ liệu: {esc(raw['status'])}</div>
    </header>
    <aside class="boundary"><strong>Ranh giới diễn giải.</strong> {esc(payload['interpretation_boundary'])}</aside>
    <section class="flow" aria-label="Luồng DSS">
      <article class="flow-step"><span class="step-no">01 · Dữ liệu vào</span><strong>{number(audit['raw_transaction_rows'])} dòng giao dịch</strong><p>{number(audit['retained_transaction_rows'])} dòng sản phẩm giữ lại sau làm sạch.</p></article>
      <article class="flow-step"><span class="step-no">02 · Snapshot</span><strong>{context['cutoff_date']}</strong><p>{context['history_window_days']} ngày lịch sử; future fields bị loại khỏi feature.</p></article>
      <article class="flow-step"><span class="step-no">03 · Điểm dự đoán</span><strong>LightGBM đã đóng băng</strong><p>Điểm queue = P(CRITICAL) + P(HIGH_RISK).</p></article>
      <article class="flow-step"><span class="step-no">04 · Rà soát</span><strong>{context['queue_counts']['review_candidate_count']} ứng viên</strong><p>Hiển thị {len(payload['alerts'])} SKU có điểm cao nhất tại cutoff.</p></article>
    </section>
    <section class="dossier">
      <article class="panel"><div class="panel-head"><div><h2>Queue cần xem</h2><p>Chọn một SKU để xem fact tại cutoff.</p></div><span>{context['cutoff_date']}</span></div><div class="queue">{alerts}</div></article>
      <aside class="panel"><div class="panel-head"><div><h2>Bằng chứng và kiểm định</h2><p>Thông tin của phiên thí nghiệm đã đóng băng.</p></div></div>
        <div class="facts"><div class="facts-grid">
          <div class="fact"><span>Horizon đã chọn</span><strong>{provenance['selected_configuration']['horizon_days']} ngày</strong></div>
          <div class="fact"><span>Nhìn lại lịch sử</span><strong>{provenance['selected_configuration']['lookback_days']} ngày</strong></div>
          <div class="fact"><span>Macro-F1 test</span><strong>{result['test_macro_f1']:.4f}</strong></div>
          <div class="fact"><span>Balanced Accuracy test</span><strong>{result['test_balanced_accuracy']:.4f}</strong></div>
          <div class="fact"><span>Recall nhóm rủi ro cao</span><strong>{result['test_high_risk_recall']:.4f}</strong></div>
          <div class="fact"><span>High-risk AP test</span><strong>{result['test_high_risk_average_precision']:.4f}</strong></div>
        </div>
        <div class="global"><h3>Tín hiệu có ảnh hưởng trung bình lớn nhất</h3><p class="provenance">TreeSHAP toàn cục; diễn giải hành vi mô hình, không chứng minh quan hệ nhân quả.</p><ol>{global_signals}</ol></div>
        <div class="global"><h3>Kiểm soát tính đúng đắn</h3><p>Ngưỡng nhãn Q25 = {provenance['selected_configuration']['q25']:.0f}, Q50 = {provenance['selected_configuration']['q50']:.0f}, fit trên train; outcome 28 ngày không có trong feature vector.</p><p class="provenance">Tệp nguồn: {esc(raw['source_file'])} · SHA-256: {esc(raw['expected_sha256'][:16])}…</p></div>
        </div>
      </aside>
    </section>
    <p class="footnote">Prototype này dùng prediction và snapshot đã lưu của nghiên cứu. Nó minh họa luồng ra quyết định và tính truy vết, không thay thế hệ thống vận hành hoặc quyết định tự động.</p>
  </main>
</body>
</html>"""


def write_outputs(payload: dict[str, Any], output_dir: Path) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / "dss_demo_data.json"
    html_path = output_dir / "dss_review_dossier.html"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    html_path.write_text(render_html(payload), encoding="utf-8")
    return json_path, html_path


def main() -> int:
    args = parse_args()
    payload = build_demo_payload(
        args.experiment_dir.resolve(), args.raw_source.resolve(), args.cutoff, args.limit
    )
    json_path, html_path = write_outputs(payload, args.output_dir.resolve())
    print("NCKH DSS prototype complete")
    print(f"JSON: {json_path}")
    print(f"HTML: {html_path}")
    print(f"Cutoff: {payload['decision_context']['cutoff_date']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
