# BÁO CÁO PROTOTYPE HỆ THỐNG HỖ TRỢ QUYẾT ĐỊNH

## Nhận diện và ưu tiên SKU có nguy cơ doanh số thấp từ dữ liệu Online Retail II

### 1. Mục tiêu báo cáo

Báo cáo này trình bày prototype hệ thống hỗ trợ quyết định (Decision Support
System – DSS) được xây dựng từ kết quả thực nghiệm NCKH. Prototype nhằm minh
họa một luồng có thể kiểm tra được: từ dữ liệu giao dịch đã làm sạch, đặc trưng
tại thời điểm ra quyết định, dự đoán rủi ro, danh sách SKU cần rà soát, đến phần
giải thích và đánh giá hồi cứu sau khi cửa sổ kết quả kết thúc.

Mục tiêu của prototype không phải là thay thế người ra quyết định. Nó hỗ trợ
người dùng tập trung vào các SKU cần được xem xét trước, đồng thời cung cấp các
bằng chứng lịch sử để người dùng kiểm tra thêm với thông tin nghiệp vụ.

### 2. Dữ liệu và phạm vi bài toán

Nghiên cứu sử dụng bộ dữ liệu công khai **Online Retail II**, ghi nhận giao
dịch của một nhà bán lẻ trực tuyến tại Vương quốc Anh. Dữ liệu ban đầu có
1.067.371 dòng giao dịch. Sau khi loại hóa đơn hủy, số lượng hoặc đơn giá không
dương, mã không phải sản phẩm và dòng trùng hoàn toàn, tập dữ liệu còn
1.003.714 giao dịch sản phẩm hợp lệ, tương ứng với 4.906 SKU.

Đơn vị phân tích là một cặp `(SKU, t0)`, trong đó `t0` là ngày chốt dự báo.
Mỗi snapshot sử dụng 90 ngày lịch sử bán hàng đến hết `t0`; kết quả thực tế là
tổng lượng bán trong 28 ngày từ `t0 + 1` đến `t0 + 28`. Có 23 cutoff theo thời
gian, tạo thành 63.675 quan sát SKU--cutoff hợp lệ.

Nghiên cứu dự báo **nguy cơ doanh số thấp trong tương lai**, không trực tiếp
nhận diện hàng tồn dư, lỗi thời hoặc thiệt hại tài chính. Online Retail II không
có dữ liệu về tồn kho thực tế, stock-out, giá vốn, biên lợi nhuận, tuổi hàng,
khuyến mãi hay chính sách nhập hàng. Vì vậy, alert từ prototype luôn được hiểu
là tín hiệu để rà soát, không phải lệnh giảm giá, thanh lý hoặc nhập hàng.

### 3. Ground Truth và kiểm soát rò rỉ dữ liệu

Tổng doanh số tương lai của SKU `i` trong horizon 28 ngày được xác định bởi:

`F_i(t0, 28) = tổng lượng bán của SKU i từ t0 + 1 đến t0 + 28`.

Nhãn rủi ro gồm bốn mức:

| Lớp | Điều kiện theo doanh số tương lai 28 ngày |
| --- | --- |
| CRITICAL | `F = 0` |
| HIGH_RISK | `0 < F ≤ 9` |
| MEDIUM_RISK | `9 < F ≤ 38` |
| LOW_RISK | `F > 38` |

Ngưỡng 9 là phân vị 25% và ngưỡng 38 là trung vị của các giá trị doanh số tương
lai dương trong tập train theo thời gian. Hai ngưỡng này được fit trên train rồi
giữ cố định khi áp dụng cho validation và test. Lớp CRITICAL được tách riêng vì
nó biểu thị SKU không có giao dịch dương nào trong toàn bộ 28 ngày kế tiếp.

Để tránh rò rỉ dữ liệu, tại cutoff `t0` mô hình chỉ dùng 24 đặc trưng lịch sử
được tính từ giao dịch có ngày không muộn hơn `t0`. Các trường thuộc tương lai,
gồm `future_qty`, `future_active_days`, `future_zero_rate`, `risk_label` và
`risk_class`, bị loại khỏi feature vector. Mã SKU, mô tả, hóa đơn, khách hàng và
quốc gia cũng không được sử dụng làm đầu vào.

### 4. Kết quả thực nghiệm liên kết với prototype

Tập dữ liệu được chia theo cutoff thời gian: train có 42.089 quan sát,
validation có 10.482 quan sát và test có 11.104 quan sát. Horizon 28 ngày được
chọn trên validation; tập test chỉ được sử dụng để đánh giá cuối cùng.

Trên 11.104 quan sát test, LightGBM đạt các chỉ số sau:

| Chỉ số | Giá trị |
| --- | ---: |
| Macro-F1 | 0,5815 |
| Balanced Accuracy | 0,6051 |
| Recall nhóm rủi ro cao | 0,7935 |
| High-risk Average Precision | 0,8024 |

Nhóm rủi ro cao trong đánh giá gồm `CRITICAL` và `HIGH_RISK`. Kết quả cho thấy
LightGBM cải thiện rõ so với quy tắc chỉ xét SKU không có bán trong 28 ngày gần
nhất. Tuy nhiên, nghiên cứu không khẳng định LightGBM vượt trội trên mọi chỉ
số: Random Forest có Macro-F1 cao hơn nhẹ (0,5838), còn Logistic Regression có
recall nhóm rủi ro cao cao hơn (0,8133). Vì vậy, kết luận phù hợp là LightGBM là
một mô hình cạnh tranh, cân bằng và có thể giải thích cho mục tiêu DSS đã nêu.

### 5. Luồng hoạt động của prototype

Prototype sử dụng prediction, metric, ngưỡng nhãn, snapshot và SHAP đã được
đóng băng từ cùng một phiên bản thực nghiệm. Prototype không huấn luyện lại mô
hình khi mở giao diện. Luồng xử lý gồm các bước:

1. Kiểm tra checksum SHA-256 của workbook nguồn với checksum đã lưu trong
   artefact thực nghiệm.
2. Chọn cutoff test; demo mặc định dùng cutoff `06/11/2011`.
3. Đọc snapshot SKU tại cutoff cùng prediction LightGBM đã lưu.
4. Tính điểm ưu tiên review: `P(CRITICAL) + P(HIGH_RISK)`.
5. Sắp xếp các SKU theo điểm ưu tiên và hiển thị các SKU đứng đầu trong queue.
6. Hiển thị fact lịch sử tại cutoff: số ngày không bán gần đây, lượng bán 28/90
   ngày, số ngày từ lần bán gần nhất và xu hướng vận tốc bán.
7. Hiển thị outcome sau 28 ngày trong một khối riêng chỉ để đánh giá hồi cứu.

Điểm ưu tiên review không phải là xác suất tồn kho dư. Nó chỉ là tổng xác suất
của hai lớp cần được xem xét sớm, dùng để thứ tự hóa nguồn lực rà soát có hạn.

### 6. Nội dung giao diện và khả năng kiểm tra

Giao diện HTML của prototype gồm bốn phần chính:

- **Nguồn và phạm vi diễn giải:** cho biết checksum workbook và nhắc rõ giới
  hạn không suy diễn tồn kho hay quan hệ nhân quả.
- **Luồng DSS:** mô tả dữ liệu đầu vào, snapshot, prediction và review queue.
- **Queue cần xem:** hiển thị các SKU có điểm review cao nhất, lớp dự đoán và
  xác suất từng lớp.
- **Fact và bằng chứng:** hiển thị chỉ số lịch sử tại cutoff, các metric test,
  ngưỡng nhãn, tín hiệu TreeSHAP toàn cục và outcome đã mature.

Việc tách riêng evidence tại cutoff khỏi outcome tương lai là thành phần quan
trọng nhất để chứng minh tính đúng đắn theo thời gian. Khi ra quyết định thực
tế, người dùng chỉ nhìn thấy evidence lịch sử và prediction; outcome chỉ có sau
28 ngày để theo dõi chất lượng mô hình.

### 7. Đối chiếu thông số trên UI với báo cáo

Bảng dưới đây là hướng dẫn để người xem đối chiếu trực tiếp giữa giao diện và
các phần của báo cáo. Các số liệu hiệu năng trên UI là số liệu của **toàn bộ tập
test 11.104 quan sát**, còn các xác suất và fact trong từng alert là số liệu của
**một SKU tại một cutoff cụ thể**. Không được nhầm hai cấp độ này với nhau.

| Thông số trên UI | Giá trị/ý nghĩa | Đối chiếu trong báo cáo | Cách diễn giải đúng |
| --- | --- | --- | --- |
| `Nguồn dữ liệu: VERIFIED` | SHA-256 workbook khớp artefact đã lưu | Mục 2 và 5 | Chứng minh prototype đang đọc đúng nguồn dữ liệu; không phải metric mô hình. |
| `1.067.371` dòng vào; `1.003.714` dòng giữ lại | Quy mô trước/sau làm sạch | Mục 2 | Cho thấy alert được tạo từ tập giao dịch đã qua quy tắc làm sạch. |
| Cutoff `06/11/2011` | Thời điểm mô phỏng quyết định | Mục 2 và 5 | Chỉ dùng giao dịch đến hết ngày này để tạo alert. |
| `90 ngày` lịch sử | Cửa sổ tạo feature | Mục 2 và 3 | Đây là phần thông tin mô hình được phép quan sát khi chấm điểm. |
| `28 ngày` horizon | Cửa sổ tạo Ground Truth | Mục 3 và 4 | Kết quả thực tế chỉ được biết sau cutoff; không nằm trong input. |
| `Q25 = 9`, `Q50 = 38` | Hai ngưỡng nhãn của doanh số tương lai dương, fit trên train | Mục 3 | Tạo bốn lớp CRITICAL/HIGH_RISK/MEDIUM_RISK/LOW_RISK; không phải ngưỡng tồn kho. |
| Macro-F1 `0,5815` | Trung bình F1 của bốn lớp trên toàn test | Mục 4 | Đo khả năng phân loại cân bằng giữa các lớp. |
| Balanced Accuracy `0,6051` | Trung bình recall của bốn lớp trên toàn test | Mục 4 | Hữu ích khi LOW_RISK chiếm tỷ lệ lớn hơn các lớp còn lại. |
| Recall nhóm rủi ro cao `0,7935` | Khả năng phát hiện nhóm CRITICAL + HIGH_RISK trên toàn test | Mục 4 | Cho biết mức bao phủ nhóm cần ưu tiên, không phải precision của queue. |
| High-risk AP `0,8024` | Chất lượng xếp hạng nhóm CRITICAL + HIGH_RISK trên toàn test | Mục 4 | Phù hợp để đánh giá score dùng sắp queue; không phải xác suất của một SKU. |
| `P(CRITICAL)`, `P(HIGH_RISK)`, ... | Xác suất bốn lớp của một SKU tại cutoff | Mục 5 | Lớp dự đoán là lớp có xác suất lớn nhất. Tổng bốn xác suất xấp xỉ 100%. |
| `Điểm queue` | `P(CRITICAL) + P(HIGH_RISK)` | Mục 5 | Chỉ dùng xếp thứ tự review. Ví dụ 96,9% không có nghĩa là 96,9% tồn kho dư. |
| `Ưu tiên rà soát rất cao` | Nhãn hiển thị của điểm queue | Mục 5 | Là mức ưu tiên giao diện, không phải Ground Truth và không thay thế nhãn bốn lớp. |
| Fact lịch sử: 7 ngày zero, bán 28/90 ngày, recency, trend | Đặc trưng tại cutoff của SKU đang chọn | Mục 3 và 5 | Hỗ trợ người dùng rà soát; không khẳng định nguyên nhân doanh số thấp. |
| TreeSHAP toàn cục | Các feature có đóng góp trung bình lớn trong LightGBM | Mục 6 | Mô tả hành vi mô hình, không chứng minh quan hệ nhân quả. |
| `Outcome sau khi cửa sổ 28 ngày đã đóng` | Lượng bán và nhãn thực tế của SKU sau maturity | Mục 3 và 6 | Chỉ xuất hiện trong demo hồi cứu để đối chiếu prediction; không được dùng khi tạo alert. |

Ví dụ tại cutoff `06/11/2011`, SKU `84796A` được dự đoán là CRITICAL với
`P(CRITICAL) = 79,21%` và `P(HIGH_RISK) = 17,69%`. Điểm queue là 96,90%, bằng
tổng của hai xác suất này; vì vậy SKU đứng đầu danh sách review. Fact lịch sử
cho thấy SKU không bán trong 28 ngày gần nhất và lần bán gần nhất cách cutoff
68 ngày. Sau 28 ngày, outcome thực tế là 2 đơn vị, thuộc HIGH_RISK. Trường hợp
này là ví dụ tốt để giải thích rằng prototype dự báo **nhóm rủi ro cao** đúng,
nhưng có thể nhầm giữa hai lớp liền kề CRITICAL và HIGH_RISK. Outcome này không
được mô hình biết khi tạo điểm tại cutoff.

### 8. Đóng góp của prototype

Prototype bổ sung cho phần thực nghiệm NCKH ở ba khía cạnh:

1. **Tính truy vết:** mỗi alert liên kết được với dữ liệu nguồn, cutoff, ngưỡng
   nhãn, cấu hình đã chọn, prediction và metric đã lưu.
2. **Tính minh bạch:** người dùng không chỉ nhận một nhãn rủi ro mà còn thấy
   các fact lịch sử và tín hiệu mô hình có liên quan.
3. **Khả năng chuyển kết quả nghiên cứu thành luồng DSS:** thay vì chỉ có bảng
   metric, mô hình tạo ra một queue ưu tiên để con người rà soát theo năng lực
   xử lý thực tế.

### 9. Giới hạn và hướng sử dụng đúng

Prototype là bằng chứng minh họa cho một quy trình nghiên cứu có kiểm soát theo
thời gian, không phải một hệ thống tồn kho triển khai trong doanh nghiệp. Kết
quả được đánh giá trên một retailer và bốn cutoff test; vì vậy không thể khẳng
định khả năng tổng quát cho retailer khác. SHAP mô tả cách mô hình sử dụng đặc
trưng đã cho, không chứng minh nguyên nhân làm doanh số thấp.

Trong triển khai thực tế, người dùng cần kết hợp alert với tồn kho hiện có,
stock-out, margin, tuổi hàng, chương trình khuyến mãi, kế hoạch delist và quy
định nghiệp vụ trước khi thực hiện hành động.

### 10. Tài liệu bàn giao

Gói ZIP đi kèm chứa mã chạy prototype, workbook nguồn, artefact cần thiết,
output HTML/JSON đã sinh sẵn, `README.md` hướng dẫn chạy và báo cáo này. Sau
khi giải nén, người dùng chỉ cần cài các thư viện được nêu trong README, chạy
prototype và mở HTML qua local server. Không cần tải thêm dữ liệu hay thực hiện
huấn luyện lại mô hình.
