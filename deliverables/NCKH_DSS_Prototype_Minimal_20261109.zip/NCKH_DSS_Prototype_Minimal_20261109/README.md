# NCKH DSS Prototype — Minimal Runnable Package

This ZIP contains only the files needed to run the Online Retail II
research DSS prototype and to read its numerical report. The prototype
reads frozen experiment artefacts; it does **not** retrain LightGBM.

## Included files

- `prototype_nckh_dss/demo.py`: generates the HTML dossier and JSON.
- `reports_NCKH/nckh_online_retail_multiclass/`: exactly the frozen
  configuration, labels, metrics, test predictions, snapshots and
  global SHAP values required by `demo.py`.
- `online_retail_II.xlsx`: source workbook used to verify provenance by
  SHA-256.
- `PROTOTYPE_REPORT_VI.md`: Vietnamese numerical report for the lecturer.
- `requirements.txt`: the two Python dependencies required at runtime.

## Prerequisite

Python 3.11 or newer and a desktop browser are required.

## Run on Linux/macOS

From the extracted ZIP folder:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python prototype_nckh_dss/demo.py --cutoff 2011-11-06 --limit 6
.venv/bin/python -m http.server 8080 --bind 127.0.0.1
```

Open this address in Chrome, Edge or Firefox:

```text
http://localhost:8080/prototype_nckh_dss/output/dss_review_dossier.html
```

Stop the local server with `Ctrl+C` after the demo.

## Run on Windows PowerShell

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe prototype_nckh_dss/demo.py --cutoff 2011-11-06 --limit 6
.\.venv\Scripts\python.exe -m http.server 8080 --bind 127.0.0.1
```

Open the same `http://localhost:8080/...` address.

## Expected result

The terminal prints `NCKH DSS prototype complete`. In the HTML dossier,
source status must be `VERIFIED`, the selected horizon must be 28 days,
and the label thresholds must be Q25 = 9 and Q50 = 38.

Do not use `xdg-open` in a headless Linux/WSL terminal; use the local
HTTP server and a browser instead.

## Interpretation boundary

This is a research decision-support prototype. Its queue score is
`P(CRITICAL) + P(HIGH_RISK)` for review prioritisation. It predicts a
transaction-derived low-future-sales outcome, not excess inventory,
obsolescence, financial loss or a causal reason for sales behaviour.
