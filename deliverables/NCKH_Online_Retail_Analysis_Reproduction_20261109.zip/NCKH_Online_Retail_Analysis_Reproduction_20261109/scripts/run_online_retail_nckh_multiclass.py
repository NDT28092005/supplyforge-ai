from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import sys
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    log_loss,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

try:
    from lightgbm import LGBMClassifier
except ImportError as error:  # pragma: no cover - exercised in environments without LightGBM
    LGBMClassifier = None  # type: ignore[assignment,misc]
    LIGHTGBM_IMPORT_ERROR = str(error)
else:
    LIGHTGBM_IMPORT_ERROR = None

CLASS_NAMES = ["CRITICAL", "HIGH_RISK", "MEDIUM_RISK", "LOW_RISK"]
CLASS_IDS = np.arange(len(CLASS_NAMES))
MODEL_LABELS = {
    "recent_zero_rule": "Recent-zero rule",
    "recent_quantile_rule": "Recent-sales quantile rule",
    "logistic_regression": "Logistic regression",
    "random_forest": "Random forest",
    "lightgbm": "LightGBM",
}
NON_PRODUCT_STOCK_CODES = frozenset(
    {
        "POST",
        "DOT",
        "M",
        "D",
        "S",
        "BANK CHARGES",
        "ADJUST",
        "AMAZONFEE",
        "CRUK",
        "B",
    }
)
FEATURE_COLUMNS = [
    "sales_qty_7d",
    "sales_qty_14d",
    "sales_qty_28d",
    "sales_qty_56d",
    "sales_qty_90d",
    "velocity_7d",
    "velocity_14d",
    "velocity_28d",
    "velocity_56d",
    "velocity_90d",
    "zero_rate_7d",
    "zero_rate_14d",
    "zero_rate_28d",
    "zero_rate_56d",
    "zero_rate_90d",
    "active_days_28d",
    "active_days_56d",
    "active_days_90d",
    "days_since_last_sale",
    "adi_90d",
    "cv2_90d",
    "velocity_trend_28d_vs_previous_56d",
    "avg_unit_price_28d",
    "price_change_28d_vs_previous_56d",
]


@dataclass(frozen=True)
class ExperimentConfig:
    lookback_days: int
    horizon_days: int
    cutoff_frequency_days: int
    min_history_quantity: float
    validation_fraction: float
    test_fraction: float
    random_state: int


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the four-class LightGBM NCKH Online Retail II experiment."
    )
    parser.add_argument("--input", type=Path, default=Path("online_retail_II.xlsx"))
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("reports/nckh_online_retail_multiclass"),
    )
    parser.add_argument(
        "--horizons",
        type=int,
        nargs="+",
        default=[14, 28, 30, 60],
        help="Future-sales horizons to compare before selecting one by validation.",
    )
    parser.add_argument("--lookback-days", type=int, default=90)
    parser.add_argument("--cutoff-frequency-days", type=int, default=28)
    parser.add_argument("--min-history-quantity", type=float, default=5.0)
    parser.add_argument("--validation-fraction", type=float, default=0.15)
    parser.add_argument("--test-fraction", type=float, default=0.15)
    parser.add_argument("--random-state", type=int, default=42)
    parser.add_argument("--rf-estimators", type=int, default=200)
    parser.add_argument("--lgbm-estimators", type=int, default=250)
    parser.add_argument(
        "--n-jobs",
        type=int,
        default=4,
        help="Bound parallel model workers for reproducible resource use.",
    )
    return parser.parse_args()


def json_default(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Not JSON serializable: {type(value)!r}")


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, default=json_default) + "\n",
        encoding="utf-8",
    )


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_online_retail(path: Path) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    """Read both sheets of the UCI workbook without requiring Excel conversion."""
    required = [
        "Invoice",
        "StockCode",
        "Description",
        "Quantity",
        "InvoiceDate",
        "Price",
        "Customer ID",
        "Country",
    ]
    if path.suffix.lower() == ".csv":
        raw = pd.read_csv(path, usecols=required)
        raw["source_sheet"] = "canonical_csv"
        raw = raw.rename(
            columns={
                "Invoice": "invoice_id",
                "StockCode": "sku",
                "Description": "description",
                "Quantity": "quantity",
                "InvoiceDate": "invoice_datetime",
                "Price": "unit_price",
                "Customer ID": "customer_id",
                "Country": "country",
            }
        )
        return raw, [
            {
                "sheet": "canonical_csv",
                "reader_engine": "pandas_csv",
                "rows": len(raw),
                "date_min": None,
                "date_max": None,
            }
        ]

    try:
        import python_calamine  # noqa: F401

        excel_engine = "calamine"
    except ImportError:
        excel_engine = "openpyxl"
    workbook = pd.ExcelFile(path, engine=excel_engine)
    frames: list[pd.DataFrame] = []
    sheet_profiles: list[dict[str, Any]] = []
    for sheet_name in workbook.sheet_names:
        frame = workbook.parse(sheet_name=sheet_name, usecols=required)
        frame["source_sheet"] = sheet_name
        sheet_profiles.append(
            {
                "sheet": sheet_name,
                "reader_engine": excel_engine,
                "rows": len(frame),
                "date_min": pd.to_datetime(frame["InvoiceDate"], errors="coerce").min(),
                "date_max": pd.to_datetime(frame["InvoiceDate"], errors="coerce").max(),
            }
        )
        frames.append(frame)
    raw = pd.concat(frames, ignore_index=True).rename(
        columns={
            "Invoice": "invoice_id",
            "StockCode": "sku",
            "Description": "description",
            "Quantity": "quantity",
            "InvoiceDate": "invoice_datetime",
            "Price": "unit_price",
            "Customer ID": "customer_id",
            "Country": "country",
        }
    )
    return raw, sheet_profiles


def clean_transactions(raw: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Apply fixed, mutually exclusive transaction-only cleaning rules."""
    df = raw.copy()
    raw_rows = len(df)
    df["invoice_id"] = df["invoice_id"].astype("string").str.strip()
    df["sku"] = df["sku"].astype("string").str.strip()
    if pd.api.types.is_numeric_dtype(df["invoice_datetime"]):
        df["invoice_datetime"] = pd.to_datetime(
            df["invoice_datetime"], unit="D", origin="1899-12-30", errors="coerce"
        )
    else:
        df["invoice_datetime"] = pd.to_datetime(
            df["invoice_datetime"], errors="coerce"
        )
    df["quantity"] = pd.to_numeric(df["quantity"], errors="coerce")
    df["unit_price"] = pd.to_numeric(df["unit_price"], errors="coerce")

    invalid_key = (
        df["invoice_id"].isna()
        | df["sku"].isna()
        | df["invoice_datetime"].isna()
        | (df["sku"] == "")
    )
    removed_missing_identifier_or_datetime = int(invalid_key.sum())
    df = df.loc[~invalid_key].copy()

    cancelled = df["invoice_id"].str.startswith("C", na=False)
    removed_cancelled_invoice_rows = int(cancelled.sum())
    df = df.loc[~cancelled].copy()

    non_positive_quantity = df["quantity"].isna() | (df["quantity"] <= 0)
    removed_non_positive_quantity_rows = int(non_positive_quantity.sum())
    df = df.loc[~non_positive_quantity].copy()

    non_positive_price = df["unit_price"].isna() | (df["unit_price"] <= 0)
    removed_non_positive_price_rows = int(non_positive_price.sum())
    df = df.loc[~non_positive_price].copy()

    # Retain genuine letter-only product codes; remove only verified service,
    # adjustment, fee and discount codes from this workbook.
    non_product_code = df["sku"].str.upper().isin(NON_PRODUCT_STOCK_CODES)
    removed_non_product_stockcode_rows = int(non_product_code.sum())
    filtered = df.loc[~non_product_code].copy()
    duplicate_mask = filtered.duplicated(
        subset=[
            "invoice_id",
            "sku",
            "description",
            "quantity",
            "invoice_datetime",
            "unit_price",
            "customer_id",
            "country",
        ],
        keep="first",
    )
    clean = filtered.loc[~duplicate_mask].copy()
    clean["date"] = clean["invoice_datetime"].dt.normalize()
    clean["description"] = clean["description"].fillna("UNKNOWN").astype(str).str.strip()
    audit = {
        "raw_rows": raw_rows,
        "removed_missing_identifier_or_datetime": removed_missing_identifier_or_datetime,
        "removed_cancelled_invoice_rows": removed_cancelled_invoice_rows,
        "removed_non_positive_quantity_rows": removed_non_positive_quantity_rows,
        "removed_non_positive_price_rows": removed_non_positive_price_rows,
        "removed_non_product_stockcode_rows": removed_non_product_stockcode_rows,
        "removed_exact_duplicate_rows_after_filtering": int(duplicate_mask.sum()),
        "retained_transaction_rows": len(clean),
        "retained_skus": int(clean["sku"].nunique()),
        "retained_date_min": clean["date"].min(),
        "retained_date_max": clean["date"].max(),
        "non_product_stockcode_exclusion_codes": sorted(NON_PRODUCT_STOCK_CODES),
        "cleaning_rules": [
            "Require invoice ID, SKU and a valid invoice timestamp.",
            "Exclude cancellation invoices whose ID starts with C.",
            "Exclude non-positive quantity and unit price rows.",
            "Exclude verified service, adjustment, fee and discount StockCodes.",
            "Remove exact duplicate transaction lines after filtering.",
        ],
    }
    return clean, audit


def _aggregate(
    daily: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp, name: str
) -> pd.Series:
    rows = daily.loc[(daily["date"] >= start) & (daily["date"] <= end)]
    return rows.groupby("sku", observed=True)["quantity"].sum().rename(name)


def _active_days(
    daily: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp, name: str
) -> pd.Series:
    rows = daily.loc[(daily["date"] >= start) & (daily["date"] <= end)]
    return rows.groupby("sku", observed=True)["date"].nunique().rename(name)


def build_snapshots(
    clean: pd.DataFrame, config: ExperimentConfig
) -> tuple[pd.DataFrame, list[pd.Timestamp]]:
    """Build point-in-time features and future-only, not-yet-labelled fields.

    Quantity and transaction-price matrices avoid repeatedly scanning the full
    transaction table for every rolling window and cutoff.
    """
    daily = (
        clean.groupby(["sku", "date"], as_index=False, observed=True)
        .agg(quantity=("quantity", "sum"))
        .sort_values(["date", "sku"])
    )
    first_date = daily["date"].min()
    last_date = daily["date"].max()
    first_cutoff = first_date + pd.Timedelta(days=config.lookback_days - 1)
    last_cutoff = last_date - pd.Timedelta(days=config.horizon_days)
    cutoffs = list(
        pd.date_range(
            first_cutoff,
            last_cutoff,
            freq=f"{config.cutoff_frequency_days}D",
        )
    )
    if len(cutoffs) < 8:
        raise ValueError("Too few cutoff dates for a 70/15/15 temporal experiment.")

    calendar = pd.date_range(first_date, last_date, freq="D")
    quantity_wide = (
        daily.pivot(index="sku", columns="date", values="quantity")
        .reindex(columns=calendar, fill_value=0.0)
        .fillna(0.0)
    )
    price_daily = clean.groupby(["sku", "date"], as_index=False, observed=True).agg(
        unit_price_sum=("unit_price", "sum"),
        unit_price_count=("unit_price", "count"),
    )
    price_sum_wide = (
        price_daily.pivot(index="sku", columns="date", values="unit_price_sum")
        .reindex(index=quantity_wide.index, columns=calendar, fill_value=0.0)
        .fillna(0.0)
    )
    price_count_wide = (
        price_daily.pivot(index="sku", columns="date", values="unit_price_count")
        .reindex(index=quantity_wide.index, columns=calendar, fill_value=0.0)
        .fillna(0.0)
    )

    def window_values(
        eligible: pd.Index, start: pd.Timestamp, end: pd.Timestamp
    ) -> np.ndarray:
        return quantity_wide.loc[eligible, start:end].to_numpy(dtype=float)

    def mean_transaction_price(
        eligible: pd.Index, start: pd.Timestamp, end: pd.Timestamp
    ) -> np.ndarray:
        price_sum = price_sum_wide.loc[eligible, start:end].sum(axis=1).to_numpy(dtype=float)
        price_count = price_count_wide.loc[eligible, start:end].sum(axis=1).to_numpy(dtype=float)
        return np.divide(
            price_sum,
            price_count,
            out=np.zeros(len(eligible), dtype=float),
            where=price_count > 0.0,
        )

    records: list[pd.DataFrame] = []
    windows = (7, 14, 28, 56, 90)
    for cutoff in cutoffs:
        start_90 = cutoff - pd.Timedelta(days=config.lookback_days - 1)
        previous_56_start = cutoff - pd.Timedelta(days=83)
        previous_56_end = cutoff - pd.Timedelta(days=28)
        hist_90_all = quantity_wide.loc[:, start_90:cutoff]
        history_qty = hist_90_all.sum(axis=1)
        eligible = history_qty.loc[history_qty >= config.min_history_quantity].index
        if eligible.empty:
            continue

        frame = pd.DataFrame(index=eligible)
        frame.index.name = "sku"
        hist_90 = window_values(eligible, start_90, cutoff)
        for window in windows:
            start = cutoff - pd.Timedelta(days=window - 1)
            qty_name = f"sales_qty_{window}d"
            active_name = f"active_days_{window}d"
            values = window_values(eligible, start, cutoff)
            frame[qty_name] = values.sum(axis=1)
            active_days = np.count_nonzero(values > 0.0, axis=1).astype(float)
            if window in {28, 56, 90}:
                frame[active_name] = active_days
            frame[f"velocity_{window}d"] = frame[qty_name] / float(window)
            frame[f"zero_rate_{window}d"] = 1.0 - active_days / float(window)

        last_sale_offsets = np.where(
            hist_90 > 0.0,
            np.arange(hist_90.shape[1], dtype=int),
            -1,
        ).max(axis=1)
        frame["days_since_last_sale"] = hist_90.shape[1] - 1 - last_sale_offsets
        frame["adi_90d"] = float(config.lookback_days) / frame[
            "active_days_90d"
        ].clip(lower=1.0)
        positive_count = np.count_nonzero(hist_90 > 0.0, axis=1)
        cv2 = np.zeros(len(eligible), dtype=float)
        enough_positive_days = positive_count > 1
        if enough_positive_days.any():
            positive_history = np.where(
                hist_90[enough_positive_days] > 0.0,
                hist_90[enough_positive_days],
                np.nan,
            )
            with np.errstate(invalid="ignore", divide="ignore"):
                cv2[enough_positive_days] = np.nan_to_num(
                    (np.nanstd(positive_history, axis=1, ddof=1) / np.nanmean(
                        positive_history, axis=1
                    )) ** 2
                )
        frame["cv2_90d"] = cv2

        previous_qty = window_values(eligible, previous_56_start, previous_56_end).sum(axis=1)
        previous_velocity = previous_qty / 56.0
        frame["velocity_trend_28d_vs_previous_56d"] = (
            frame["velocity_28d"].to_numpy(dtype=float)
            / np.where(previous_velocity > 0.0, previous_velocity, np.nan)
        )
        frame["velocity_trend_28d_vs_previous_56d"] = np.nan_to_num(
            frame["velocity_trend_28d_vs_previous_56d"], nan=0.0, posinf=0.0, neginf=0.0
        )

        price_28 = mean_transaction_price(eligible, cutoff - pd.Timedelta(days=27), cutoff)
        price_previous = mean_transaction_price(eligible, previous_56_start, previous_56_end)
        frame["avg_unit_price_28d"] = price_28
        frame["price_change_28d_vs_previous_56d"] = np.nan_to_num(
            price_28 / np.where(price_previous > 0.0, price_previous, np.nan) - 1.0,
            nan=0.0,
            posinf=0.0,
            neginf=0.0,
        )

        future_start = cutoff + pd.Timedelta(days=1)
        future_end = cutoff + pd.Timedelta(days=config.horizon_days)
        future_values = window_values(eligible, future_start, future_end)
        frame["future_qty"] = future_values.sum(axis=1)
        frame["future_active_days"] = np.count_nonzero(
            future_values > 0.0, axis=1
        ).astype(float)
        frame["future_zero_rate"] = 1.0 - frame["future_active_days"] / float(
            config.horizon_days
        )
        frame["cutoff_date"] = cutoff
        records.append(frame.reset_index())

    snapshots = pd.concat(records, ignore_index=True)
    snapshots[FEATURE_COLUMNS] = snapshots[FEATURE_COLUMNS].replace(
        [np.inf, -np.inf], np.nan
    )
    return snapshots, cutoffs


def chronological_split(
    snapshots: pd.DataFrame, validation_fraction: float, test_fraction: float
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    dates = sorted(pd.to_datetime(snapshots["cutoff_date"].unique()))
    n_dates = len(dates)
    test_count = max(2, math.ceil(n_dates * test_fraction))
    validation_count = max(2, math.ceil(n_dates * validation_fraction))
    train_count = n_dates - validation_count - test_count
    if train_count < 4:
        raise ValueError("Temporal split leaves too few training cutoff dates.")
    train_dates = dates[:train_count]
    validation_dates = dates[train_count : train_count + validation_count]
    test_dates = dates[train_count + validation_count :]
    train = snapshots.loc[snapshots["cutoff_date"].isin(train_dates)].copy()
    validation = snapshots.loc[
        snapshots["cutoff_date"].isin(validation_dates)
    ].copy()
    test = snapshots.loc[snapshots["cutoff_date"].isin(test_dates)].copy()
    split = {
        "split_method": "strict chronological split by decision cutoff date",
        "fractions_requested": {
            "train": 1.0 - validation_fraction - test_fraction,
            "validation": validation_fraction,
            "test": test_fraction,
        },
        "train_cutoff_dates": [pd.Timestamp(value).date().isoformat() for value in train_dates],
        "validation_cutoff_dates": [
            pd.Timestamp(value).date().isoformat() for value in validation_dates
        ],
        "test_cutoff_dates": [pd.Timestamp(value).date().isoformat() for value in test_dates],
        "train_rows": len(train),
        "validation_rows": len(validation),
        "test_rows": len(test),
        "actual_row_fractions": {
            "train": len(train) / len(snapshots),
            "validation": len(validation) / len(snapshots),
            "test": len(test) / len(snapshots),
        },
        "decision_time_semantics": (
            "The decision cutoff is the end of the stated calendar day: features use "
            "transactions dated on or before the cutoff, and the target begins the "
            "following day."
        ),
        "adjacent_target_windows": (
            "With cutoff frequency equal to the selected horizon, adjacent target "
            "windows are contiguous and non-overlapping; their endpoints may coincide "
            "with the next snapshot's feature cutoff under end-of-day semantics."
        ),
        "feature_columns": FEATURE_COLUMNS,
        "future_fields_excluded_from_features": [
            "future_qty",
            "future_active_days",
            "future_zero_rate",
            "risk_label",
            "risk_class",
        ],
    }
    return train, validation, test, split


def fit_label_policy(train: pd.DataFrame) -> dict[str, Any]:
    positive = train.loc[train["future_qty"] > 0, "future_qty"]
    if positive.empty:
        raise ValueError("Training period has no positive future-sales rows.")
    q25 = float(positive.quantile(0.25))
    q50 = float(positive.quantile(0.50))
    if q50 <= q25:
        q50 = float(np.nextafter(q25, np.inf))
    return {
        "strategy": (
            "CRITICAL is zero future quantity. Positive future quantities are "
            "split at the training-period 25th and 50th percentiles."
        ),
        "quantile_method": "linear",
        "positive_future_qty_q25": q25,
        "positive_future_qty_q50": q50,
        "class_order": CLASS_NAMES,
        "feature_columns": FEATURE_COLUMNS,
        "future_fields_excluded_from_features": [
            "future_qty",
            "future_active_days",
            "future_zero_rate",
            "risk_label",
            "risk_class",
        ],
        "class_semantics": {
            "CRITICAL": "No observed positive sales in the future horizon.",
            "HIGH_RISK": "Positive sales in the lowest training-period quartile.",
            "MEDIUM_RISK": "Positive sales between the 25th and 50th percentiles.",
            "LOW_RISK": "Positive sales above the 50th percentile.",
        },
        "fit_rows": len(train),
        "fit_cutoff_max": pd.Timestamp(train["cutoff_date"].max()),
    }


def apply_label_policy(frame: pd.DataFrame, policy: dict[str, Any]) -> pd.DataFrame:
    result = frame.copy()
    q25 = float(policy["positive_future_qty_q25"])
    q50 = float(policy["positive_future_qty_q50"])
    values = result["future_qty"].to_numpy(dtype=float)
    labels = np.select(
        [values <= 0, values <= q25, values <= q50],
        [0, 1, 2],
        default=3,
    ).astype(int)
    result["risk_label"] = labels
    result["risk_class"] = pd.Categorical(
        [CLASS_NAMES[index] for index in labels],
        categories=CLASS_NAMES,
        ordered=True,
    )
    return result


def _probability_frame(probabilities: np.ndarray) -> np.ndarray:
    probabilities = np.asarray(probabilities, dtype=float)
    if probabilities.ndim != 2 or probabilities.shape[1] != len(CLASS_NAMES):
        raise ValueError(f"Expected a 4-class probability matrix, got {probabilities.shape}.")
    return np.clip(probabilities, 1e-9, 1.0)


def multiclass_metrics(y_true: pd.Series, probabilities: np.ndarray) -> dict[str, Any]:
    probabilities = _probability_frame(probabilities)
    y_array = np.asarray(y_true, dtype=int)
    predictions = probabilities.argmax(axis=1)
    matrix = confusion_matrix(y_array, predictions, labels=CLASS_IDS)
    per_class = {}
    precision = precision_score(
        y_array, predictions, labels=CLASS_IDS, average=None, zero_division=0
    )
    recall = recall_score(
        y_array, predictions, labels=CLASS_IDS, average=None, zero_division=0
    )
    f1 = f1_score(
        y_array, predictions, labels=CLASS_IDS, average=None, zero_division=0
    )
    support = np.bincount(y_array, minlength=len(CLASS_NAMES))
    for index, name in enumerate(CLASS_NAMES):
        per_class[name] = {
            "precision": round(float(precision[index]), 6),
            "recall": round(float(recall[index]), 6),
            "f1": round(float(f1[index]), 6),
            "support": int(support[index]),
        }
    high_true = (y_array <= 1).astype(int)
    high_score = probabilities[:, 0] + probabilities[:, 1]
    high_prediction = (predictions <= 1).astype(int)
    precision_recall_x, precision_recall_y, _ = precision_recall_curve(
        high_true, high_score
    )
    result: dict[str, Any] = {
        "accuracy": round(float(accuracy_score(y_array, predictions)), 6),
        "macro_f1": round(float(f1_score(y_array, predictions, average="macro", zero_division=0)), 6),
        "weighted_f1": round(
            float(f1_score(y_array, predictions, average="weighted", zero_division=0)), 6
        ),
        "balanced_accuracy": round(
            float(balanced_accuracy_score(y_array, predictions)), 6
        ),
        "ordinal_mae": round(float(np.abs(y_array - predictions).mean()), 6),
        "critical_recall": round(float(recall[0]), 6),
        "high_risk_recall": round(float(recall[1]), 6),
        "high_risk_group_recall": round(
            float(recall_score(high_true, high_prediction, zero_division=0)), 6
        ),
        "high_risk_group_precision": round(
            float(precision_score(high_true, high_prediction, zero_division=0)), 6
        ),
        "high_risk_pr_auc": round(
            float(average_precision_score(high_true, high_score)), 6
        ),
        "log_loss": round(float(log_loss(y_array, probabilities, labels=CLASS_IDS)), 6),
        "confusion_matrix": matrix.tolist(),
        "per_class": per_class,
        "class_support": {CLASS_NAMES[i]: int(support[i]) for i in range(len(CLASS_NAMES))},
        "high_risk_pr_curve": {
            "precision": precision_recall_x.tolist(),
            "recall": precision_recall_y.tolist(),
            "score_definition": "P(CRITICAL) + P(HIGH_RISK)",
        },
    }
    if len(np.unique(y_array)) == len(CLASS_NAMES):
        result["macro_roc_auc_ovr"] = round(
            float(
                roc_auc_score(
                    y_array,
                    probabilities,
                    average="macro",
                    multi_class="ovr",
                    labels=CLASS_IDS,
                )
            ),
            6,
        )
    else:
        result["macro_roc_auc_ovr"] = None
    return result


def recent_zero_rule(frame: pd.DataFrame) -> np.ndarray:
    probability = np.zeros((len(frame), len(CLASS_NAMES)), dtype=float)
    critical = frame["sales_qty_28d"].to_numpy(dtype=float) <= 0
    probability[critical, 0] = 1.0
    probability[~critical, 3] = 1.0
    return probability


def fit_recent_quantile_rule(train: pd.DataFrame) -> dict[str, float]:
    positive = train.loc[train["sales_qty_28d"] > 0, "sales_qty_28d"]
    if positive.empty:
        return {"q25": 0.0, "q50": 0.0}
    q25 = float(positive.quantile(0.25))
    q50 = float(positive.quantile(0.50))
    if q50 <= q25:
        q50 = float(np.nextafter(q25, np.inf))
    return {"q25": q25, "q50": q50}


def recent_quantile_rule(frame: pd.DataFrame, thresholds: dict[str, float]) -> np.ndarray:
    values = frame["sales_qty_28d"].to_numpy(dtype=float)
    labels = np.select(
        [values <= 0, values <= thresholds["q25"], values <= thresholds["q50"]],
        [0, 1, 2],
        default=3,
    ).astype(int)
    probability = np.zeros((len(frame), len(CLASS_NAMES)), dtype=float)
    probability[np.arange(len(frame)), labels] = 1.0
    return probability


def fit_models(
    train: pd.DataFrame,
    validation: pd.DataFrame,
    test: pd.DataFrame,
    random_state: int,
    rf_estimators: int,
    lgbm_estimators: int,
    n_jobs: int,
) -> tuple[dict[str, Any], dict[str, Any], pd.DataFrame, pd.DataFrame]:
    if LGBMClassifier is None:
        raise ImportError(f"LightGBM is required: {LIGHTGBM_IMPORT_ERROR}")
    x_train = train[FEATURE_COLUMNS]
    x_validation = validation[FEATURE_COLUMNS]
    x_test = test[FEATURE_COLUMNS]
    y_train = train["risk_label"].astype(int)
    y_validation = validation["risk_label"].astype(int)
    y_test = test["risk_label"].astype(int)
    if y_train.nunique() < len(CLASS_NAMES):
        raise ValueError(
            f"Training split must contain all four classes; got {sorted(y_train.unique())}."
        )

    model_probabilities: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    model_objects: dict[str, Any] = {}
    rule_thresholds = fit_recent_quantile_rule(train)
    model_probabilities["recent_zero_rule"] = (
        recent_zero_rule(validation),
        recent_zero_rule(test),
    )
    model_probabilities["recent_quantile_rule"] = (
        recent_quantile_rule(validation, rule_thresholds),
        recent_quantile_rule(test, rule_thresholds),
    )

    logistic = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            (
                "model",
                LogisticRegression(
                    max_iter=300,
                    tol=1e-3,
                    class_weight="balanced",
                    random_state=random_state,
                    solver="lbfgs",
                ),
            ),
        ]
    )
    logistic.fit(x_train, y_train)
    model_probabilities["logistic_regression"] = (
        logistic.predict_proba(x_validation),
        logistic.predict_proba(x_test),
    )
    model_objects["logistic_regression"] = logistic

    forest_imputer = SimpleImputer(strategy="median")
    forest_train = forest_imputer.fit_transform(x_train)
    forest_validation = forest_imputer.transform(x_validation)
    forest_test = forest_imputer.transform(x_test)
    forest = RandomForestClassifier(
        n_estimators=rf_estimators,
        max_depth=16,
        min_samples_leaf=2,
        max_features="sqrt",
        class_weight="balanced_subsample",
        n_jobs=n_jobs,
        random_state=random_state,
    )
    forest.fit(forest_train, y_train)
    model_probabilities["random_forest"] = (
        forest.predict_proba(forest_validation),
        forest.predict_proba(forest_test),
    )
    model_objects["random_forest"] = (forest, forest_imputer)

    lgbm = LGBMClassifier(
        objective="multiclass",
        num_class=len(CLASS_NAMES),
        n_estimators=lgbm_estimators,
        learning_rate=0.05,
        num_leaves=31,
        max_depth=-1,
        min_child_samples=30,
        subsample=0.9,
        colsample_bytree=0.9,
        reg_lambda=1.0,
        class_weight="balanced",
        random_state=random_state,
        n_jobs=n_jobs,
        verbosity=-1,
    )
    lgbm.fit(x_train, y_train)
    model_probabilities["lightgbm"] = (
        _probability_frame(lgbm.predict_proba(x_validation)),
        _probability_frame(lgbm.predict_proba(x_test)),
    )
    model_objects["lightgbm"] = lgbm

    metrics: dict[str, Any] = {
        "class_order": CLASS_NAMES,
        "primary_selection_metric": "validation_macro_f1",
        "models": {},
    }
    validation_predictions = validation[
        ["sku", "cutoff_date", "future_qty", "future_zero_rate", "risk_label", "risk_class"]
    ].copy()
    test_predictions = test[
        ["sku", "cutoff_date", "future_qty", "future_zero_rate", "risk_label", "risk_class"]
    ].copy()
    for name, (validation_probability, test_probability) in model_probabilities.items():
        metrics["models"][name] = {
            "definition": {
                "recent_zero_rule": "CRITICAL if the latest 28-day sales quantity is zero; otherwise LOW_RISK.",
                "recent_quantile_rule": "Map latest 28-day sales to inverse-risk bins using training positive-sales q25/q50.",
                "logistic_regression": "Class-balanced multinomial logistic regression over temporal features.",
                "random_forest": "Class-balanced random forest over temporal features.",
                "lightgbm": "Class-balanced multiclass LightGBM over temporal features.",
            }[name],
            "validation": multiclass_metrics(y_validation, validation_probability),
            "test": multiclass_metrics(y_test, test_probability),
        }
        if name == "recent_quantile_rule":
            metrics["models"][name]["rule_thresholds"] = {
                **rule_thresholds,
                "basis": (
                    "Quantiles of sales_qty_28d among training snapshots; these are "
                    "historical baseline thresholds and are distinct from future-label "
                    "thresholds."
                ),
            }
        if name == "logistic_regression":
            metrics["models"][name]["hyperparameters"] = {
                "max_iter": 300,
                "tol": 1e-3,
                "class_weight": "balanced",
                "solver": "lbfgs",
                "random_state": random_state,
            }
        if name == "random_forest":
            metrics["models"][name]["hyperparameters"] = {
                "n_estimators": rf_estimators,
                "max_depth": 16,
                "min_samples_leaf": 2,
                "max_features": "sqrt",
                "class_weight": "balanced_subsample",
                "random_state": random_state,
                "n_jobs": n_jobs,
            }
        if name == "lightgbm":
            metrics["models"][name]["hyperparameters"] = {
                "n_estimators": lgbm_estimators,
                "learning_rate": 0.05,
                "num_leaves": 31,
                "min_child_samples": 30,
                "class_weight": "balanced",
                "random_state": random_state,
                "n_jobs": n_jobs,
            }
        for index, class_name in enumerate(CLASS_NAMES):
            validation_predictions[f"{name}_prob_{class_name}"] = validation_probability[:, index]
            test_predictions[f"{name}_prob_{class_name}"] = test_probability[:, index]
        validation_predictions[f"{name}_prediction"] = validation_probability.argmax(axis=1)
        validation_predictions[f"{name}_prediction_name"] = [
            CLASS_NAMES[index] for index in validation_probability.argmax(axis=1)
        ]
        test_predictions[f"{name}_prediction"] = test_probability.argmax(axis=1)
        test_predictions[f"{name}_prediction_name"] = [
            CLASS_NAMES[index] for index in test_probability.argmax(axis=1)
        ]
    metrics["label_prevalence"] = {
        "train": train["risk_class"].value_counts(normalize=True).reindex(CLASS_NAMES, fill_value=0).to_dict(),
        "validation": validation["risk_class"].value_counts(normalize=True).reindex(CLASS_NAMES, fill_value=0).to_dict(),
        "test": test["risk_class"].value_counts(normalize=True).reindex(CLASS_NAMES, fill_value=0).to_dict(),
    }
    return metrics, model_objects, validation_predictions, test_predictions


def write_shap_outputs(
    model_objects: dict[str, Any],
    test: pd.DataFrame,
    output_dir: Path,
    sample_size: int = 400,
) -> dict[str, Any]:
    # SHAP imports Matplotlib; delaying it avoids a high memory peak while the
    # two-sheet workbook is still being parsed and cleaned.
    try:
        import shap
    except ImportError as error:  # pragma: no cover - optional dependency
        return {"status": "SKIPPED", "reason": str(error)}
    model = model_objects["lightgbm"]
    sample = test.sort_values("cutoff_date").copy()
    if len(sample) > sample_size:
        sample = sample.sample(sample_size, random_state=42)
    transformed = sample[FEATURE_COLUMNS]
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(transformed)
    if isinstance(shap_values, list):
        values_by_class = [np.asarray(values) for values in shap_values]
    else:
        values_array = np.asarray(shap_values)
        if values_array.ndim != 3:
            raise ValueError(f"Unexpected multiclass SHAP shape: {values_array.shape}")
        if values_array.shape[2] == len(CLASS_NAMES):
            values_by_class = [values_array[:, :, index] for index in CLASS_IDS]
        elif values_array.shape[1] == len(CLASS_NAMES):
            values_by_class = [values_array[:, index, :] for index in CLASS_IDS]
        else:
            raise ValueError(f"Unexpected multiclass SHAP shape: {values_array.shape}")

    importance = pd.DataFrame({"feature": FEATURE_COLUMNS})
    for index, class_name in enumerate(CLASS_NAMES):
        importance[f"mean_abs_shap_{class_name}"] = np.abs(
            values_by_class[index]
        ).mean(axis=0)
    class_columns = [f"mean_abs_shap_{name}" for name in CLASS_NAMES]
    importance["mean_abs_shap_mean"] = importance[class_columns].mean(axis=1)
    importance.sort_values("mean_abs_shap_mean", ascending=False).to_csv(
        output_dir / "shap_global_importance.csv", index=False
    )

    probability = _probability_frame(model.predict_proba(transformed))
    critical_candidates = np.where(sample["risk_label"].to_numpy(dtype=int) == 0)[0]
    if len(critical_candidates):
        local_index = int(
            critical_candidates[np.argmax(probability[critical_candidates, 0])]
        )
    else:
        local_index = int(np.argmax(probability[:, 0]))
    local_values = values_by_class[0][local_index]
    local = pd.DataFrame(
        {
            "feature": FEATURE_COLUMNS,
            "feature_value": transformed.iloc[local_index].to_numpy(dtype=float),
            "shap_value": local_values,
        }
    )
    local["absolute_shap"] = local["shap_value"].abs()
    local["direction"] = np.where(
        local["shap_value"] > 0,
        "INCREASES_CRITICAL_CLASS_SCORE",
        np.where(
            local["shap_value"] < 0,
            "DECREASES_CRITICAL_CLASS_SCORE",
            "NEUTRAL",
        ),
    )
    local = local.sort_values("absolute_shap", ascending=False)
    row = sample.iloc[local_index]
    local_payload = {
        "status": "COMPLETED",
        "method": "TreeSHAP for the fitted multiclass LightGBM",
        "explained_class": "CRITICAL",
        "shap_output_scale": "LightGBM raw multiclass margin for the CRITICAL class",
        "sample_size": len(sample),
        "case": {
            "sku": str(row["sku"]),
            "cutoff_date": row["cutoff_date"],
            "actual_class": str(row["risk_class"]),
            "predicted_class": CLASS_NAMES[int(probability[local_index].argmax())],
            "model_probabilities": {
                CLASS_NAMES[index]: float(probability[local_index, index])
                for index in CLASS_IDS
            },
            "future_qty_label_only": float(row["future_qty"]),
        },
        "top_feature_attributions": local.head(10).to_dict(orient="records"),
        "interpretation_boundary": (
            "SHAP attributes this model output to supplied transaction features. "
            "It does not establish a causal reason for weak sales or confirm inventory state."
        ),
    }
    write_json(output_dir / "shap_local_example.json", local_payload)
    return {
        "status": "COMPLETED",
        "global_importance": "shap_global_importance.csv",
        "local_example": "shap_local_example.json",
        "sample_size": len(sample),
    }


def write_horizon_summary(
    output_dir: Path,
    horizon: int,
    config: ExperimentConfig,
    profile: dict[str, Any],
    split: dict[str, Any],
    label_policy: dict[str, Any],
    metrics: dict[str, Any],
    model_objects: dict[str, Any],
    test_frame: pd.DataFrame,
    validation_predictions: pd.DataFrame,
    test_predictions: pd.DataFrame,
) -> dict[str, Any]:
    horizon_dir = output_dir / f"horizon_{horizon:03d}d"
    horizon_dir.mkdir(parents=True, exist_ok=True)
    validation_predictions.to_csv(horizon_dir / "validation_predictions.csv", index=False)
    test_predictions.to_csv(horizon_dir / "test_predictions.csv", index=False)
    test_predictions.sort_values(
        ["lightgbm_prob_CRITICAL", "lightgbm_prob_HIGH_RISK"],
        ascending=False,
    ).head(100).to_csv(horizon_dir / "top_risk_cases.csv", index=False)
    write_json(horizon_dir / "dataset_profile.json", profile)
    write_json(horizon_dir / "temporal_split.json", split)
    write_json(horizon_dir / "label_definition.json", label_policy)
    write_json(horizon_dir / "metrics.json", metrics)
    shap_result = write_shap_outputs(model_objects, test_frame, horizon_dir)
    write_json(horizon_dir / "shap_status.json", shap_result)
    return {
        "horizon_days": horizon,
        "snapshot_rows": profile["snapshot_rows"],
        "test_rows": split["test_rows"],
        "test_prevalence": metrics["label_prevalence"]["test"],
        "validation_lightgbm_macro_f1": metrics["models"]["lightgbm"]["validation"]["macro_f1"],
        "validation_lightgbm_high_risk_recall": metrics["models"]["lightgbm"]["validation"]["high_risk_group_recall"],
        "test_lightgbm_macro_f1": metrics["models"]["lightgbm"]["test"]["macro_f1"],
        "test_lightgbm_high_risk_recall": metrics["models"]["lightgbm"]["test"]["high_risk_group_recall"],
        "test_lightgbm_balanced_accuracy": metrics["models"]["lightgbm"]["test"]["balanced_accuracy"],
        "shap_status": shap_result["status"],
    }


def write_summary(
    output_dir: Path,
    source: Path,
    selected_horizon: int,
    selected_metrics: dict[str, Any],
    sensitivity: pd.DataFrame,
) -> None:
    models = selected_metrics["models"]
    lines = [
        "# NCKH Online Retail II Multiclass Experiment",
        "",
        "This run identifies a transaction-derived slow-moving sales-risk signal.",
        "It does not observe inventory, stockouts, capital exposure or causal reasons",
        "for weak sales.",
        "",
        f"- Source: `{source}`",
        f"- Selected horizon: **{selected_horizon} days** (chosen by validation macro-F1)",
        f"- Classes: `{', '.join(CLASS_NAMES)}`",
        "- Primary metric: validation/test Macro-F1; high-risk recall is reported separately.",
        "",
        "## Selected Test Results",
        "",
        "| Model | Macro-F1 | Balanced accuracy | High-risk recall | High-risk PR-AUC |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for name, payload in models.items():
        test = payload["test"]
        lines.append(
            f"| {MODEL_LABELS.get(name, name)} | {test['macro_f1']:.4f} | {test['balanced_accuracy']:.4f} | "
            f"{test['high_risk_group_recall']:.4f} | {test['high_risk_pr_auc']:.4f} |"
        )
    lines.extend(
        [
            "",
            "## Horizon Selection",
            "",
            "The test period was not used to select the horizon.",
            "",
            "| Horizon (days) | Validation Macro-F1 | Test Macro-F1 | Test high-risk recall | Selected |",
            "| ---: | ---: | ---: | ---: | :---: |",
        ]
    )
    for _, row in sensitivity.sort_values("horizon_days").iterrows():
        lines.append(
            f"| {int(row['horizon_days'])} | "
            f"{float(row['validation_lightgbm_macro_f1']):.4f} | "
            f"{float(row['test_lightgbm_macro_f1']):.4f} | "
            f"{float(row['test_lightgbm_high_risk_recall']):.4f} | "
            f"{'yes' if bool(row['selected']) else 'no'} |"
        )
    lines.extend(
        [
            "",
            "SHAP values explain fitted LightGBM attribution and are not causal explanations.",
        ]
    )
    (output_dir / "experiment_summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    args = parse_args()
    if not args.input.is_file():
        raise FileNotFoundError(f"Input workbook not found: {args.input}")
    if not args.horizons or any(value <= 0 for value in args.horizons):
        raise ValueError("--horizons must contain positive integers.")
    if args.validation_fraction <= 0 or args.test_fraction <= 0:
        raise ValueError("Validation and test fractions must be positive.")
    if args.validation_fraction + args.test_fraction >= 0.5:
        raise ValueError("Validation plus test fractions must be less than 0.5.")
    if args.n_jobs <= 0:
        raise ValueError("--n-jobs must be positive.")
    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    raw, sheet_profiles = read_online_retail(args.input)
    clean, cleaning_audit = clean_transactions(raw)
    del raw
    source_profile = {
        "source_file": str(args.input),
        "source_sha256": sha256_file(args.input),
        "sheet_profiles": sheet_profiles,
        "cleaning_audit": cleaning_audit,
    }

    sensitivity_rows: list[dict[str, Any]] = []
    horizon_payloads: dict[int, dict[str, Any]] = {}
    for horizon in sorted(set(args.horizons)):
        config = ExperimentConfig(
            lookback_days=args.lookback_days,
            horizon_days=horizon,
            cutoff_frequency_days=args.cutoff_frequency_days,
            min_history_quantity=args.min_history_quantity,
            validation_fraction=args.validation_fraction,
            test_fraction=args.test_fraction,
            random_state=args.random_state,
        )
        snapshots, cutoffs = build_snapshots(clean, config)
        train_raw, validation_raw, test_raw, split = chronological_split(
            snapshots, args.validation_fraction, args.test_fraction
        )
        label_policy = fit_label_policy(train_raw)
        train = apply_label_policy(train_raw, label_policy)
        validation = apply_label_policy(validation_raw, label_policy)
        test = apply_label_policy(test_raw, label_policy)
        metrics, model_objects, validation_predictions, test_predictions = fit_models(
            train,
            validation,
            test,
            args.random_state,
            args.rf_estimators,
            args.lgbm_estimators,
            args.n_jobs,
        )
        labeled_snapshots = apply_label_policy(snapshots, label_policy)
        profile = {
            **source_profile,
            "horizon_days": horizon,
            "lookback_days": args.lookback_days,
            "snapshot_rows": len(snapshots),
            "snapshot_skus": int(snapshots["sku"].nunique()),
            "scheduled_cutoffs": [date.date().isoformat() for date in cutoffs],
            "risk_class_prevalence": labeled_snapshots["risk_class"]
            .value_counts(normalize=True)
            .reindex(CLASS_NAMES, fill_value=0)
            .to_dict(),
        }
        horizon_dir = output_dir / f"horizon_{horizon:03d}d"
        horizon_dir.mkdir(parents=True, exist_ok=True)
        labeled_snapshots.to_parquet(horizon_dir / "snapshots.parquet", index=False)
        horizon_result = write_horizon_summary(
            output_dir,
            horizon,
            config,
            profile,
            split,
            {**label_policy, "config": asdict(config)},
            metrics,
            model_objects,
            test,
            validation_predictions,
            test_predictions,
        )
        horizon_payloads[horizon] = {
            "config": config,
            "snapshots": snapshots,
            "train": train,
            "validation": validation,
            "test": test,
            "metrics": metrics,
            "profile": profile,
            "split": split,
            "label_policy": label_policy,
            "result": horizon_result,
        }
        sensitivity_rows.append(horizon_result)
        print(
            f"horizon={horizon}d snapshots={len(snapshots):,} "
            f"validation_macro_f1={horizon_result['validation_lightgbm_macro_f1']:.4f}"
        )

    sensitivity = pd.DataFrame(sensitivity_rows).sort_values("horizon_days")
    selection_order = sensitivity.sort_values(
        [
            "validation_lightgbm_macro_f1",
            "validation_lightgbm_high_risk_recall",
        ],
        ascending=False,
    )
    selected_horizon = int(selection_order.iloc[0]["horizon_days"])
    sensitivity["selected"] = sensitivity["horizon_days"].eq(selected_horizon)
    sensitivity.to_csv(output_dir / "horizon_sensitivity.csv", index=False)
    selected = horizon_payloads[selected_horizon]

    selected_dir = output_dir / "selected"
    selected_dir.mkdir(parents=True, exist_ok=True)
    selected_horizon_dir = output_dir / f"horizon_{selected_horizon:03d}d"
    for filename in [
        "snapshots.parquet",
        "validation_predictions.csv",
        "test_predictions.csv",
        "top_risk_cases.csv",
        "dataset_profile.json",
        "temporal_split.json",
        "label_definition.json",
        "metrics.json",
        "shap_global_importance.csv",
        "shap_local_example.json",
        "shap_status.json",
    ]:
        source = selected_horizon_dir / filename
        target = selected_dir / filename
        if source.exists():
            target.write_bytes(source.read_bytes())
    selected_metrics = selected["metrics"]
    write_json(
        output_dir / "selected_config.json",
        {
            "selection_rule": "max validation LightGBM macro-F1, then validation high-risk recall",
            "selected_horizon_days": selected_horizon,
            "selected_model": "lightgbm",
            "candidate_horizons_days": sorted(horizon_payloads),
            "label_policy": {**selected["label_policy"], "config": asdict(selected["config"])},
        },
    )
    write_json(
        output_dir / "dataset_profile.json",
        {
            **selected["profile"],
            "selected_horizon_days": selected_horizon,
            "selected_class_prevalence": selected_metrics["label_prevalence"],
        },
    )
    write_json(output_dir / "metrics.json", selected_metrics)
    write_json(
        output_dir / "run_metadata.json",
        {
            "runner": "scripts/run_online_retail_nckh_multiclass.py",
            "run_at_utc": datetime.now(timezone.utc),
            "python": sys.version,
            "platform": platform.platform(),
            "pandas": pd.__version__,
            "numpy": np.__version__,
            "lightgbm_import_error": LIGHTGBM_IMPORT_ERROR,
            "shap_import_error": "Imported lazily; see per-horizon shap_status.json.",
            "random_state": args.random_state,
        },
    )
    write_summary(output_dir, args.input, selected_horizon, selected_metrics, sensitivity)
    print(f"Completed multiclass NCKH experiment. Results: {output_dir}")
    print(f"Selected horizon: {selected_horizon} days")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
