#!/usr/bin/env python3
"""Run pre-specified NCKH ablation and ground-truth sensitivity experiments.

The canonical 28-day experiment under ``selected/`` is read-only.  This
script writes a separate ``robustness/`` release so that post-hoc robustness
checks never overwrite the frozen predictions, metrics, or model selection.

Both analyses keep the chronological 15/4/4 cutoff partition fixed:

* Feature-family ablation fits the frozen LightGBM configuration after dropping
  one pre-declared, disjoint feature family at a time.
* Ground-truth sensitivity keeps CRITICAL = 0 and the 28-day horizon fixed,
  but re-fits each positive-sales quantile policy on training snapshots only,
  then re-labels validation/test and refits the same LightGBM configuration.

Neither experiment selects a replacement primary model, horizon, or label
policy.  Their role is to describe robustness of the already selected design.
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import run_online_retail_nckh_multiclass as core


FEATURE_FAMILIES: dict[str, dict[str, Any]] = {
    "sales_velocity": {
        "label": "Sales quantity and velocity",
        "columns": [
            "sales_qty_7d",
            "sales_qty_14d",
            "sales_qty_28d",
            "sales_qty_56d",
            "sales_qty_90d",
            "velocity_7d",
            "velocity_14d",
            "velocity_28d",
            "velocity_56d",
            "velocity_90d",
        ],
    },
    "intermittency": {
        "label": "Intermittency and recency",
        "columns": [
            "zero_rate_7d",
            "zero_rate_14d",
            "zero_rate_28d",
            "zero_rate_56d",
            "zero_rate_90d",
            "active_days_28d",
            "active_days_56d",
            "active_days_90d",
            "days_since_last_sale",
        ],
    },
    "demand_pattern": {
        "label": "Demand pattern",
        "columns": [
            "adi_90d",
            "cv2_90d",
            "velocity_trend_28d_vs_previous_56d",
        ],
    },
    "price": {
        "label": "Price",
        "columns": [
            "avg_unit_price_28d",
            "price_change_28d_vs_previous_56d",
        ],
    },
}

GROUND_TRUTH_POLICIES: tuple[dict[str, Any], ...] = (
    {
        "policy_id": "q20_q50",
        "label": "Q20 / Q50",
        "lower_quantile": 0.20,
        "upper_quantile": 0.50,
        "description": "Narrower positive-sales HIGH_RISK band; median LOW_RISK boundary unchanged.",
    },
    {
        "policy_id": "q25_q50_canonical",
        "label": "Q25 / Q50 (canonical)",
        "lower_quantile": 0.25,
        "upper_quantile": 0.50,
        "description": "Frozen primary ground-truth policy.",
    },
    {
        "policy_id": "q33_q67",
        "label": "Q33 / Q67",
        "lower_quantile": 1.0 / 3.0,
        "upper_quantile": 2.0 / 3.0,
        "description": "Broader positive-sales HIGH_RISK band and stricter LOW_RISK boundary.",
    },
)

REPORT_METRICS = (
    "macro_f1",
    "balanced_accuracy",
    "high_risk_group_recall",
    "high_risk_pr_auc",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run pre-specified feature ablation and label-policy sensitivity."
    )
    parser.add_argument(
        "--experiment-dir",
        type=Path,
        default=Path("reports_NCKH/nckh_online_retail_multiclass"),
        help="Frozen NCKH experiment directory containing selected/ artefacts.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Output release directory; defaults to <experiment-dir>/robustness.",
    )
    parser.add_argument("--n-jobs", type=int, default=4)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, default=core.json_default) + "\n",
        encoding="utf-8",
    )


def validate_feature_families() -> None:
    grouped = [column for family in FEATURE_FAMILIES.values() for column in family["columns"]]
    duplicates = sorted({column for column in grouped if grouped.count(column) > 1})
    missing = sorted(set(core.FEATURE_COLUMNS) - set(grouped))
    unexpected = sorted(set(grouped) - set(core.FEATURE_COLUMNS))
    if duplicates or missing or unexpected:
        raise ValueError(
            "Feature families must form a disjoint partition of FEATURE_COLUMNS; "
            f"duplicates={duplicates}, missing={missing}, unexpected={unexpected}."
        )


def validate_selected_release(experiment_dir: Path) -> None:
    selected = experiment_dir / "selected"
    required = (
        selected / "snapshots.parquet",
        selected / "temporal_split.json",
        selected / "metrics.json",
        selected / "label_definition.json",
        experiment_dir / "selected_config.json",
    )
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError("Missing frozen experiment artefacts: " + ", ".join(missing))


def load_fixed_partitions(experiment_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    selected = experiment_dir / "selected"
    snapshots = pd.read_parquet(selected / "snapshots.parquet")
    split = read_json(selected / "temporal_split.json")
    snapshots["cutoff_date"] = pd.to_datetime(snapshots["cutoff_date"])
    partitions: list[pd.DataFrame] = []
    for name in ("train", "validation", "test"):
        cutoff_dates = pd.to_datetime(split[f"{name}_cutoff_dates"])
        frame = snapshots.loc[snapshots["cutoff_date"].isin(cutoff_dates)].copy()
        expected_rows = int(split[f"{name}_rows"])
        if len(frame) != expected_rows:
            raise ValueError(
                f"{name} has {len(frame):,} rows in snapshots.parquet, expected {expected_rows:,}."
            )
        partitions.append(frame)
    return partitions[0], partitions[1], partitions[2], split


def lgbm_parameters(selected_metrics: dict[str, Any], n_jobs: int) -> dict[str, Any]:
    saved = selected_metrics["models"]["lightgbm"]["hyperparameters"]
    return {
        "objective": "multiclass",
        "num_class": len(core.CLASS_NAMES),
        "n_estimators": int(saved["n_estimators"]),
        "learning_rate": float(saved["learning_rate"]),
        "num_leaves": int(saved["num_leaves"]),
        "max_depth": -1,
        "min_child_samples": int(saved["min_child_samples"]),
        "subsample": 0.9,
        "colsample_bytree": 0.9,
        "reg_lambda": 1.0,
        "class_weight": saved["class_weight"],
        "random_state": int(saved["random_state"]),
        "n_jobs": n_jobs,
        "verbosity": -1,
    }


def run_lightgbm(
    train: pd.DataFrame,
    validation: pd.DataFrame,
    test: pd.DataFrame,
    feature_columns: list[str],
    parameters: dict[str, Any],
) -> tuple[dict[str, dict[str, Any]], pd.DataFrame, pd.DataFrame]:
    if core.LGBMClassifier is None:
        raise ImportError(f"LightGBM is required: {core.LIGHTGBM_IMPORT_ERROR}")
    model = core.LGBMClassifier(**parameters)
    model.fit(train[feature_columns], train["risk_label"].astype(int))
    validation_probability = core._probability_frame(model.predict_proba(validation[feature_columns]))
    test_probability = core._probability_frame(model.predict_proba(test[feature_columns]))
    metrics = {
        "validation": core.multiclass_metrics(validation["risk_label"], validation_probability),
        "test": core.multiclass_metrics(test["risk_label"], test_probability),
    }
    return metrics, prediction_frame(validation, validation_probability), prediction_frame(test, test_probability)


def prediction_frame(frame: pd.DataFrame, probabilities: np.ndarray) -> pd.DataFrame:
    columns = ["sku", "cutoff_date", "future_qty", "risk_label", "risk_class"]
    result = frame[columns].copy()
    for index, class_name in enumerate(core.CLASS_NAMES):
        result[f"prob_{class_name}"] = probabilities[:, index]
    predicted = probabilities.argmax(axis=1)
    result["prediction"] = predicted
    result["prediction_class"] = [core.CLASS_NAMES[index] for index in predicted]
    return result


def metric_columns(prefix: str, metrics: dict[str, Any]) -> dict[str, float]:
    return {f"{prefix}_{name}": float(metrics[name]) for name in REPORT_METRICS}


def class_distribution(frame: pd.DataFrame, prefix: str) -> dict[str, float | int]:
    counts = frame["risk_class"].value_counts().reindex(core.CLASS_NAMES, fill_value=0)
    result: dict[str, float | int] = {f"{prefix}_rows": int(len(frame))}
    for class_name in core.CLASS_NAMES:
        result[f"{prefix}_{class_name}_count"] = int(counts[class_name])
        result[f"{prefix}_{class_name}_share"] = float(counts[class_name] / len(frame))
    return result


def ablation_conditions() -> tuple[dict[str, Any], ...]:
    all_columns = list(core.FEATURE_COLUMNS)
    conditions: list[dict[str, Any]] = [
        {
            "condition_id": "all_features",
            "label": "All 24 features",
            "dropped_family": "None",
            "dropped_columns": [],
            "feature_columns": all_columns,
        }
    ]
    for family_id, family in FEATURE_FAMILIES.items():
        dropped = list(family["columns"])
        conditions.append(
            {
                "condition_id": f"drop_{family_id}",
                "label": f"Drop: {family['label']}",
                "dropped_family": family["label"],
                "dropped_columns": dropped,
                "feature_columns": [column for column in all_columns if column not in dropped],
            }
        )
    return tuple(conditions)


def run_feature_ablation(
    train: pd.DataFrame,
    validation: pd.DataFrame,
    test: pd.DataFrame,
    parameters: dict[str, Any],
    output_dir: Path,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    validation_outputs: list[pd.DataFrame] = []
    test_outputs: list[pd.DataFrame] = []
    for condition in ablation_conditions():
        metrics, validation_prediction, test_prediction = run_lightgbm(
            train, validation, test, list(condition["feature_columns"]), parameters
        )
        row: dict[str, Any] = {
            "condition_id": condition["condition_id"],
            "condition_label": condition["label"],
            "dropped_family": condition["dropped_family"],
            "dropped_columns": ";".join(condition["dropped_columns"]),
            "features_retained": len(condition["feature_columns"]),
            "features_removed": len(condition["dropped_columns"]),
            **metric_columns("validation", metrics["validation"]),
            **metric_columns("test", metrics["test"]),
        }
        rows.append(row)
        for partition, prediction, collection in (
            ("validation", validation_prediction, validation_outputs),
            ("test", test_prediction, test_outputs),
        ):
            payload = prediction.copy()
            payload.insert(0, "partition", partition)
            payload.insert(0, "condition_id", condition["condition_id"])
            collection.append(payload)
        print(
            f"ablation={condition['condition_id']} retained={len(condition['feature_columns'])} "
            f"test_macro_f1={metrics['test']['macro_f1']:.4f}"
        )

    summary = pd.DataFrame(rows)
    reference = summary.loc[summary["condition_id"].eq("all_features")].iloc[0]
    for metric in REPORT_METRICS:
        summary[f"test_delta_{metric}_vs_all_features"] = (
            summary[f"test_{metric}"] - float(reference[f"test_{metric}"])
        )
    output_dir.mkdir(parents=True, exist_ok=True)
    summary.to_csv(output_dir / "ablation_metrics.csv", index=False)
    pd.concat(validation_outputs, ignore_index=True).to_csv(
        output_dir / "ablation_validation_predictions.csv", index=False
    )
    pd.concat(test_outputs, ignore_index=True).to_csv(
        output_dir / "ablation_test_predictions.csv", index=False
    )
    write_json(
        output_dir / "ablation_protocol.json",
        {
            "purpose": "Drop-one-feature-family ablation of the frozen selected LightGBM configuration.",
            "reference_condition": "all_features",
            "feature_families": FEATURE_FAMILIES,
            "conditions": [
                {
                    key: value
                    for key, value in condition.items()
                    if key != "feature_columns"
                }
                | {"feature_columns": condition["feature_columns"]}
                for condition in ablation_conditions()
            ],
            "fixed_elements": [
                "28-day horizon",
                "canonical Q25/Q50 future-sales label policy",
                "chronological 15/4/4 cutoff split",
                "LightGBM hyperparameters and random_state",
            ],
        },
    )
    return summary


def fit_ground_truth_policy(train_raw: pd.DataFrame, policy_spec: dict[str, Any]) -> dict[str, Any]:
    positive = train_raw.loc[train_raw["future_qty"] > 0, "future_qty"]
    if positive.empty:
        raise ValueError("Training partition has no positive future-sales quantities.")
    lower = float(positive.quantile(float(policy_spec["lower_quantile"])))
    upper = float(positive.quantile(float(policy_spec["upper_quantile"])))
    if upper <= lower:
        upper = float(np.nextafter(lower, np.inf))
    return {
        "strategy": "CRITICAL is zero future quantity; positive future quantities split at train-only policy quantiles.",
        "policy_id": policy_spec["policy_id"],
        "policy_label": policy_spec["label"],
        "description": policy_spec["description"],
        "quantile_method": "linear",
        "lower_quantile": float(policy_spec["lower_quantile"]),
        "upper_quantile": float(policy_spec["upper_quantile"]),
        "positive_future_qty_q_lower": lower,
        "positive_future_qty_q_upper": upper,
        "fit_rows": int(len(train_raw)),
        "fit_cutoff_max": pd.Timestamp(train_raw["cutoff_date"].max()),
        "class_order": core.CLASS_NAMES,
    }


def apply_ground_truth_policy(frame: pd.DataFrame, policy: dict[str, Any]) -> pd.DataFrame:
    result = frame.copy()
    values = result["future_qty"].to_numpy(dtype=float)
    lower = float(policy["positive_future_qty_q_lower"])
    upper = float(policy["positive_future_qty_q_upper"])
    labels = np.select(
        [values <= 0, values <= lower, values <= upper], [0, 1, 2], default=3
    ).astype(int)
    result["risk_label"] = labels
    result["risk_class"] = pd.Categorical(
        [core.CLASS_NAMES[index] for index in labels],
        categories=core.CLASS_NAMES,
        ordered=True,
    )
    return result


def run_ground_truth_sensitivity(
    train_raw: pd.DataFrame,
    validation_raw: pd.DataFrame,
    test_raw: pd.DataFrame,
    parameters: dict[str, Any],
    output_dir: Path,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    validation_outputs: list[pd.DataFrame] = []
    test_outputs: list[pd.DataFrame] = []
    policies: list[dict[str, Any]] = []
    for policy_spec in GROUND_TRUTH_POLICIES:
        policy = fit_ground_truth_policy(train_raw, policy_spec)
        train = apply_ground_truth_policy(train_raw, policy)
        validation = apply_ground_truth_policy(validation_raw, policy)
        test = apply_ground_truth_policy(test_raw, policy)
        metrics, validation_prediction, test_prediction = run_lightgbm(
            train, validation, test, list(core.FEATURE_COLUMNS), parameters
        )
        row: dict[str, Any] = {
            "policy_id": policy["policy_id"],
            "policy_label": policy["policy_label"],
            "lower_quantile": policy["lower_quantile"],
            "upper_quantile": policy["upper_quantile"],
            "fitted_lower_threshold": policy["positive_future_qty_q_lower"],
            "fitted_upper_threshold": policy["positive_future_qty_q_upper"],
            **metric_columns("validation", metrics["validation"]),
            **metric_columns("test", metrics["test"]),
            **class_distribution(train, "train"),
            **class_distribution(validation, "validation"),
            **class_distribution(test, "test"),
        }
        rows.append(row)
        policies.append(policy)
        for partition, prediction, collection in (
            ("validation", validation_prediction, validation_outputs),
            ("test", test_prediction, test_outputs),
        ):
            payload = prediction.copy()
            payload.insert(0, "partition", partition)
            payload.insert(0, "policy_id", policy["policy_id"])
            collection.append(payload)
        print(
            f"ground_truth={policy['policy_id']} thresholds="
            f"({policy['positive_future_qty_q_lower']:.4g}, {policy['positive_future_qty_q_upper']:.4g}) "
            f"test_macro_f1={metrics['test']['macro_f1']:.4f}"
        )

    summary = pd.DataFrame(rows)
    canonical = summary.loc[summary["policy_id"].eq("q25_q50_canonical")].iloc[0]
    for metric in REPORT_METRICS:
        summary[f"test_delta_{metric}_vs_canonical"] = (
            summary[f"test_{metric}"] - float(canonical[f"test_{metric}"])
        )
    output_dir.mkdir(parents=True, exist_ok=True)
    summary.to_csv(output_dir / "ground_truth_sensitivity_metrics.csv", index=False)
    pd.concat(validation_outputs, ignore_index=True).to_csv(
        output_dir / "ground_truth_sensitivity_validation_predictions.csv", index=False
    )
    pd.concat(test_outputs, ignore_index=True).to_csv(
        output_dir / "ground_truth_sensitivity_test_predictions.csv", index=False
    )
    write_json(
        output_dir / "ground_truth_policies.json",
        {
            "purpose": "Train-only positive-future-sales threshold sensitivity with fixed 28-day horizon and fixed LightGBM configuration.",
            "policies": policies,
            "fixed_elements": [
                "CRITICAL = future_qty == 0",
                "28-day horizon",
                "24 historical input features",
                "chronological 15/4/4 cutoff split",
                "LightGBM hyperparameters and random_state",
            ],
            "interpretation": (
                "Metrics are evaluated within each relabelled task. They describe sensitivity "
                "to a transparent target-definition choice and do not select a replacement policy."
            ),
        },
    )
    return summary


def plot_ablation(summary: pd.DataFrame, path: Path) -> None:
    display = summary.copy()
    labels = display["condition_label"].tolist()
    x = np.arange(len(display))
    width = 0.24
    metric_specs = (
        ("test_macro_f1", "Macro-F1"),
        ("test_balanced_accuracy", "Balanced accuracy"),
        ("test_high_risk_pr_auc", "High-risk AP"),
    )
    figure, axis = plt.subplots(figsize=(11, 5.7))
    for index, (metric, label) in enumerate(metric_specs):
        bars = axis.bar(x + (index - 1) * width, display[metric], width, label=label)
        axis.bar_label(bars, fmt="%.3f", fontsize=8, padding=2)
    axis.set_ylim(0, 1)
    axis.set_xticks(x, labels, rotation=18, ha="right")
    axis.set_ylabel("Test metric")
    axis.set_title("Feature-family ablation: frozen 28-day LightGBM")
    axis.legend(ncol=3, loc="upper center")
    axis.grid(axis="y", alpha=0.25)
    figure.tight_layout()
    figure.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(figure)


def plot_ground_truth_sensitivity(summary: pd.DataFrame, path: Path) -> None:
    display = summary.copy()
    labels = display["policy_label"].tolist()
    x = np.arange(len(display))
    figure, axes = plt.subplots(1, 2, figsize=(12.5, 5.4))

    metric_specs = (
        ("test_macro_f1", "Macro-F1"),
        ("test_balanced_accuracy", "Balanced accuracy"),
        ("test_high_risk_pr_auc", "High-risk AP"),
    )
    width = 0.23
    for index, (metric, label) in enumerate(metric_specs):
        bars = axes[0].bar(x + (index - 1) * width, display[metric], width, label=label)
        axes[0].bar_label(bars, fmt="%.3f", fontsize=8, padding=2)
    axes[0].set_ylim(0, 1)
    axes[0].set_xticks(x, labels, rotation=15, ha="right")
    axes[0].set_title("Test metrics within each relabelled task")
    axes[0].grid(axis="y", alpha=0.25)
    axes[0].legend(fontsize=8)

    stack_bottom = np.zeros(len(display))
    colours = ("#c95d63", "#ec9f5a", "#86b049", "#4f86c6")
    for class_name, colour in zip(core.CLASS_NAMES, colours, strict=True):
        shares = display[f"test_{class_name}_share"].to_numpy(dtype=float)
        axes[1].bar(labels, shares, bottom=stack_bottom, label=class_name, color=colour)
        stack_bottom += shares
    axes[1].set_ylim(0, 1)
    axes[1].set_title("Test class distribution induced by each policy")
    axes[1].set_ylabel("Share of test snapshots")
    axes[1].tick_params(axis="x", rotation=15)
    axes[1].legend(fontsize=8, loc="upper right")
    axes[1].grid(axis="y", alpha=0.25)
    figure.tight_layout()
    figure.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(figure)


def format_table(frame: pd.DataFrame, columns: list[str]) -> list[str]:
    header = "| " + " | ".join(columns) + " |"
    separator = "|" + "|".join([" --- " for _ in columns]) + "|"
    rows = [header, separator]
    for _, row in frame.iterrows():
        values = []
        for column in columns:
            value = row[column]
            if isinstance(value, (float, np.floating)):
                values.append(f"{float(value):.4f}")
            else:
                values.append(str(value))
        rows.append("| " + " | ".join(values) + " |")
    return rows


def write_report(
    output_dir: Path,
    ablation: pd.DataFrame,
    ground_truth: pd.DataFrame,
) -> None:
    lines = [
        "# NCKH robustness experiments",
        "",
        "This release is separate from the frozen selected experiment. It does not replace the selected 28-day LightGBM; it tests the robustness of that fixed choice.",
        "",
        "## Feature-family ablation",
        "",
        "All conditions preserve the 28-day horizon, canonical Q25/Q50 labels, chronological 15/4/4 cutoff split, LightGBM hyperparameters and random state. Each non-reference condition removes exactly one pre-declared, disjoint feature family.",
        "",
        *format_table(
            ablation,
            [
                "condition_label",
                "features_retained",
                "test_macro_f1",
                "test_balanced_accuracy",
                "test_high_risk_group_recall",
                "test_high_risk_pr_auc",
            ],
        ),
        "",
        "The result is descriptive: a negative delta after removing a family indicates that the family contributes information under this retailer/test-period design. It is not a causal attribution.",
        "",
        "## Ground-truth threshold sensitivity",
        "",
        "Every policy keeps CRITICAL = 0 and the 28-day horizon. Positive-sales thresholds are fitted from chronological training data only; validation and test are relabelled using those frozen thresholds, and the same LightGBM configuration is refit. Metrics therefore belong to different, transparent label definitions and must not be used to select a policy after inspecting test outcomes.",
        "",
        *format_table(
            ground_truth,
            [
                "policy_label",
                "fitted_lower_threshold",
                "fitted_upper_threshold",
                "test_macro_f1",
                "test_balanced_accuracy",
                "test_high_risk_group_recall",
                "test_high_risk_pr_auc",
            ],
        ),
        "",
        "## Files",
        "",
        "- `ablation_metrics.csv` and `ground_truth_sensitivity_metrics.csv`: report-ready numerical results.",
        "- `ablation_test_predictions.csv` and `ground_truth_sensitivity_test_predictions.csv`: row-level persisted predictions.",
        "- `ablation_feature_family.png` and `ground_truth_policy_sensitivity.png`: 300-DPI figures.",
        "- `ablation_protocol.json`, `ground_truth_policies.json`, and `robustness_manifest.json`: auditable protocol and provenance.",
    ]
    (output_dir / "ROBUSTNESS_EXPERIMENTS.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def verify_canonical_reproduction(
    ablation: pd.DataFrame,
    ground_truth: pd.DataFrame,
    selected_metrics: dict[str, Any],
) -> None:
    """Fail closed if either canonical control cannot reproduce selected/.

    The all-features ablation and Q25/Q50 policy are deliberately duplicated
    controls. Their agreement demonstrates that robustness metrics were not
    accidentally calculated from a different split, feature list, or model
    configuration.
    """
    expected = selected_metrics["models"]["lightgbm"]["test"]
    controls = {
        "all_features": ablation.loc[
            ablation["condition_id"].eq("all_features")
        ].iloc[0],
        "q25_q50_canonical": ground_truth.loc[
            ground_truth["policy_id"].eq("q25_q50_canonical")
        ].iloc[0],
    }
    mismatches: list[str] = []
    for control_name, row in controls.items():
        for metric in REPORT_METRICS:
            actual = float(row[f"test_{metric}"])
            expected_value = float(expected[metric])
            if not np.isclose(actual, expected_value, rtol=0.0, atol=1e-9):
                mismatches.append(
                    f"{control_name}.{metric}={actual} != selected={expected_value}"
                )
    if mismatches:
        raise AssertionError(
            "Canonical controls failed to reproduce the frozen selected metrics: "
            + "; ".join(mismatches)
        )


def main() -> int:
    args = parse_args()
    if args.n_jobs <= 0:
        raise ValueError("--n-jobs must be positive.")
    experiment_dir = args.experiment_dir
    validate_feature_families()
    validate_selected_release(experiment_dir)
    output_dir = args.output_dir or experiment_dir / "robustness"
    output_dir.mkdir(parents=True, exist_ok=True)

    train_raw, validation_raw, test_raw, split = load_fixed_partitions(experiment_dir)
    selected_metrics = read_json(experiment_dir / "selected" / "metrics.json")
    selected_config = read_json(experiment_dir / "selected_config.json")
    label_definition = read_json(experiment_dir / "selected" / "label_definition.json")
    parameters = lgbm_parameters(selected_metrics, args.n_jobs)

    canonical_train = core.apply_label_policy(train_raw, label_definition)
    canonical_validation = core.apply_label_policy(validation_raw, label_definition)
    canonical_test = core.apply_label_policy(test_raw, label_definition)
    ablation = run_feature_ablation(
        canonical_train,
        canonical_validation,
        canonical_test,
        parameters,
        output_dir,
    )
    ground_truth = run_ground_truth_sensitivity(
        train_raw,
        validation_raw,
        test_raw,
        parameters,
        output_dir,
    )
    verify_canonical_reproduction(ablation, ground_truth, selected_metrics)
    plot_ablation(ablation, output_dir / "ablation_feature_family.png")
    plot_ground_truth_sensitivity(
        ground_truth, output_dir / "ground_truth_policy_sensitivity.png"
    )
    write_report(output_dir, ablation, ground_truth)
    write_json(
        output_dir / "robustness_manifest.json",
        {
            "generated_at_utc": datetime.now(timezone.utc),
            "script": "scripts/run_nckh_robustness_experiments.py",
            "frozen_experiment_dir": str(experiment_dir),
            "frozen_selected_config": selected_config,
            "input_label_definition": label_definition,
            "fixed_split": split,
            "lightgbm_parameters": parameters,
            "feature_family_partition": FEATURE_FAMILIES,
            "ground_truth_policy_specs": list(GROUND_TRUTH_POLICIES),
            "output_contract": (
                "Robustness outputs are separate from selected/ and do not overwrite the canonical experiment."
            ),
        },
    )
    print(f"NCKH robustness experiments complete: {output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
