#!/usr/bin/env python3
"""Generate review-driven diagnostics from a completed NCKH experiment.

The script never selects a new primary model or horizon. It adds auditable
evidence around the already selected configuration: realised split shares,
per-cutoff performance, shortlist quality, recent-zero transitions, a boundary
exclusion robustness check, and SHAP stability across test cutoffs.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.metrics import (
    average_precision_score,
    balanced_accuracy_score,
    f1_score,
    precision_score,
    recall_score,
)


CLASS_NAMES = ["CRITICAL", "HIGH_RISK", "MEDIUM_RISK", "LOW_RISK"]
MODEL_LABELS = {
    "recent_zero_rule": "Recent-zero rule",
    "recent_quantile_rule": "Recent-sales quantile rule",
    "logistic_regression": "Logistic regression",
    "random_forest": "Random forest",
    "lightgbm": "LightGBM",
}
FEATURE_COLUMNS = [
    "sales_qty_7d",
    "sales_qty_14d",
    "sales_qty_28d",
    "sales_qty_56d",
    "sales_qty_90d",
    "velocity_7d",
    "velocity_14d",
    "velocity_28d",
    "velocity_56d",
    "velocity_90d",
    "zero_rate_7d",
    "zero_rate_14d",
    "zero_rate_28d",
    "zero_rate_56d",
    "zero_rate_90d",
    "active_days_28d",
    "active_days_56d",
    "active_days_90d",
    "days_since_last_sale",
    "adi_90d",
    "cv2_90d",
    "velocity_trend_28d_vs_previous_56d",
    "avg_unit_price_28d",
    "price_change_28d_vs_previous_56d",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create temporal, DSS-ranking and SHAP diagnostics."
    )
    parser.add_argument(
        "--experiment-dir",
        type=Path,
        default=Path("reports/nckh_online_retail_multiclass"),
    )
    parser.add_argument(
        "--shap-samples-per-cutoff",
        type=int,
        default=400,
        help="Fixed sample cap used for each test cutoff in SHAP stability analysis.",
    )
    parser.add_argument(
        "--skip-shap",
        action="store_true",
        help="Generate temporal and ranking diagnostics without refitting SHAP.",
    )
    parser.add_argument(
        "--bootstrap-repetitions",
        type=int,
        default=500,
        help="SKU-cluster bootstrap repetitions for paired model differences.",
    )
    return parser.parse_args()


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def json_default(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, (pd.Timestamp, datetime, date)):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Cannot serialize {type(value)!r}")


def write_json(path: Path, payload: Any) -> None:
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, default=json_default) + "\n",
        encoding="utf-8",
    )


def probability_columns(model_name: str) -> list[str]:
    return [f"{model_name}_prob_{class_name}" for class_name in CLASS_NAMES]


def calculate_metrics(frame: pd.DataFrame, model_name: str) -> dict[str, float | int]:
    probability = frame[probability_columns(model_name)].to_numpy(dtype=float)
    actual = frame["risk_label"].to_numpy(dtype=int)
    predicted = probability.argmax(axis=1)
    actual_high = actual < 2
    predicted_high = predicted < 2
    high_score = probability[:, :2].sum(axis=1)
    return {
        "n_rows": len(frame),
        "macro_f1": float(f1_score(actual, predicted, average="macro")),
        "balanced_accuracy": float(balanced_accuracy_score(actual, predicted)),
        "high_risk_recall": float(recall_score(actual_high, predicted_high)),
        "high_risk_precision": float(
            precision_score(actual_high, predicted_high, zero_division=0)
        ),
        "high_risk_pr_auc": float(average_precision_score(actual_high, high_score)),
    }


def per_cutoff_metrics(predictions: pd.DataFrame, model_names: list[str]) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for cutoff_date, frame in predictions.groupby("cutoff_date", sort=True):
        for model_name in model_names:
            rows.append(
                {
                    "cutoff_date": cutoff_date,
                    "model": model_name,
                    "model_label": MODEL_LABELS[model_name],
                    **calculate_metrics(frame, model_name),
                }
            )
    return pd.DataFrame(rows).sort_values(["model", "cutoff_date"])


def ranking_metrics(predictions: pd.DataFrame, model_names: list[str]) -> pd.DataFrame:
    shortlist_sizes = (100, math.ceil(len(predictions) * 0.05))
    actual_high = predictions["risk_label"].lt(2)
    rows: list[dict[str, Any]] = []
    for model_name in model_names:
        score = predictions[f"{model_name}_prob_CRITICAL"] + predictions[
            f"{model_name}_prob_HIGH_RISK"
        ]
        # Stable ties make the rule baseline's arbitrary tied scores reproducible.
        order = score.sort_values(ascending=False, kind="mergesort").index
        for k in shortlist_sizes:
            top = actual_high.loc[order[:k]]
            rows.append(
                {
                    "model": model_name,
                    "model_label": MODEL_LABELS[model_name],
                    "k": k,
                    "selection_fraction": k / len(predictions),
                    "high_risk_cases_at_k": int(top.sum()),
                    "precision_at_k": float(top.mean()),
                    "recall_at_k": float(top.sum() / actual_high.sum()),
                    "score_definition": "P(CRITICAL) + P(HIGH_RISK)",
                }
            )
    return pd.DataFrame(rows).sort_values(["k", "model"])


def sku_cluster_bootstrap(
    predictions: pd.DataFrame, repetitions: int, random_state: int = 42
) -> pd.DataFrame:
    """Estimate paired model differences while retaining all rows for a sampled SKU.

    Repeated snapshots of the same SKU are correlated. Resampling SKU clusters,
    rather than individual SKU-cutoff rows, gives a more defensible uncertainty
    summary for this panel-style test set. It is not a replacement for external
    retailer validation or a block bootstrap across many independent cutoffs.
    """
    if repetitions <= 0:
        raise ValueError("bootstrap repetitions must be positive")
    model_pairs = [
        ("lightgbm", "recent_zero_rule"),
        ("lightgbm", "recent_quantile_rule"),
        ("lightgbm", "logistic_regression"),
        ("lightgbm", "random_forest"),
    ]
    metrics = ("macro_f1", "balanced_accuracy", "high_risk_recall", "high_risk_pr_auc")
    sku_rows = [
        group.index.to_numpy(dtype=int)
        for _, group in predictions.groupby("sku", sort=False)
    ]
    rng = np.random.default_rng(random_state)
    actual = predictions["risk_label"].to_numpy(dtype=int)
    cache = {
        name: predictions[probability_columns(name)].to_numpy(dtype=float)
        for name in {name for pair in model_pairs for name in pair}
    }
    observed = {name: calculate_metrics(predictions, name) for name in cache}
    samples: dict[tuple[str, str, str], list[float]] = {
        (candidate, reference, metric): []
        for candidate, reference in model_pairs
        for metric in metrics
    }
    for _ in range(repetitions):
        chosen_clusters = rng.integers(0, len(sku_rows), size=len(sku_rows))
        indices = np.concatenate([sku_rows[index] for index in chosen_clusters])
        y_true = actual[indices]
        for candidate, reference in model_pairs:
            candidate_frame = pd.DataFrame(
                cache[candidate][indices], columns=probability_columns(candidate)
            )
            reference_frame = pd.DataFrame(
                cache[reference][indices], columns=probability_columns(reference)
            )
            candidate_frame["risk_label"] = y_true
            reference_frame["risk_label"] = y_true
            candidate_metrics = calculate_metrics(candidate_frame, candidate)
            reference_metrics = calculate_metrics(reference_frame, reference)
            for metric in metrics:
                samples[(candidate, reference, metric)].append(
                    float(candidate_metrics[metric] - reference_metrics[metric])
                )
    rows: list[dict[str, Any]] = []
    for candidate, reference in model_pairs:
        for metric in metrics:
            values = np.asarray(samples[(candidate, reference, metric)])
            rows.append(
                {
                    "candidate_model": candidate,
                    "reference_model": reference,
                    "metric": metric,
                    "observed_difference": float(
                        observed[candidate][metric] - observed[reference][metric]
                    ),
                    "ci_95_lower": float(np.quantile(values, 0.025)),
                    "ci_95_upper": float(np.quantile(values, 0.975)),
                    "bootstrap_probability_difference_gt_zero": float((values > 0.0).mean()),
                    "repetitions": repetitions,
                    "cluster_unit": "SKU",
                }
            )
    return pd.DataFrame(rows)


def recent_zero_transition(
    predictions: pd.DataFrame, snapshots: pd.DataFrame
) -> pd.DataFrame:
    snapshot_keys = snapshots[["sku", "cutoff_date", "sales_qty_28d"]].copy()
    snapshot_keys["cutoff_date"] = snapshot_keys["cutoff_date"].astype(str)
    joined = predictions[["sku", "cutoff_date", "risk_class"]].merge(
        snapshot_keys,
        on=["sku", "cutoff_date"],
        validate="one_to_one",
    )
    rows: list[dict[str, Any]] = []
    for cutoff_date, frame in joined.groupby("cutoff_date", sort=True):
        recent_zero = frame.loc[frame["sales_qty_28d"].eq(0)]
        for risk_class in CLASS_NAMES:
            rows.append(
                {
                    "cutoff_date": cutoff_date,
                    "risk_class": risk_class,
                    "count": int(recent_zero["risk_class"].eq(risk_class).sum()),
                    "share_within_recent_zero": float(
                        recent_zero["risk_class"].eq(risk_class).mean()
                    ),
                }
            )
    total = joined.loc[joined["sales_qty_28d"].eq(0)]
    for risk_class in CLASS_NAMES:
        rows.append(
            {
                "cutoff_date": "ALL_TEST_CUTOFFS",
                "risk_class": risk_class,
                "count": int(total["risk_class"].eq(risk_class).sum()),
                "share_within_recent_zero": float(total["risk_class"].eq(risk_class).mean()),
            }
        )
    return pd.DataFrame(rows)


def boundary_exclusion_sensitivity(experiment_dir: Path) -> pd.DataFrame:
    """Score saved predictions after dropping the shared-boundary cutoff.

    This is a robustness diagnostic only: the fitted model and labels are not
    changed, and no result here selects a horizon or model.
    """
    rows: list[dict[str, Any]] = []
    for horizon_dir in sorted(experiment_dir.glob("horizon_*d")):
        horizon = int(horizon_dir.name.split("_")[1].removesuffix("d"))
        for partition in ("validation", "test"):
            predictions = pd.read_csv(horizon_dir / f"{partition}_predictions.csv")
            excluded_cutoff = str(predictions["cutoff_date"].min())
            retained = predictions.loc[predictions["cutoff_date"].ne(excluded_cutoff)]
            rows.append(
                {
                    "horizon_days": horizon,
                    "partition": partition,
                    "excluded_first_cutoff": excluded_cutoff,
                    "retained_rows": len(retained),
                    **calculate_metrics(retained, "lightgbm"),
                }
            )
    return pd.DataFrame(rows).sort_values(["partition", "horizon_days"])


def split_audit(
    split: dict[str, Any], label_definition: dict[str, Any], metrics: dict[str, Any]
) -> dict[str, Any]:
    horizon = int(label_definition["config"]["horizon_days"])
    total_rows = sum(split[f"{name}_rows"] for name in ("train", "validation", "test"))
    actual_row_fractions = split.get(
        "actual_row_fractions",
        {
            name: split[f"{name}_rows"] / total_rows
            for name in ("train", "validation", "test")
        },
    )
    boundaries = []
    for left_name, right_name in (("train", "validation"), ("validation", "test")):
        left = split[f"{left_name}_cutoff_dates"][-1]
        right = split[f"{right_name}_cutoff_dates"][0]
        left_timestamp = pd.Timestamp(left)
        boundaries.append(
            {
                "boundary": f"{left_name}_to_{right_name}",
                "last_left_cutoff": left,
                "first_right_cutoff": right,
                "last_left_target_start": (left_timestamp + pd.Timedelta(days=1)).date(),
                "last_left_target_end": (left_timestamp + pd.Timedelta(days=horizon)).date(),
                "right_target_start": (pd.Timestamp(right) + pd.Timedelta(days=1)).date(),
                "target_windows_overlap": False,
                "shared_boundary_day_with_right_feature_cutoff": (
                    left_timestamp + pd.Timedelta(days=horizon) == pd.Timestamp(right)
                ),
            }
        )
    rule_thresholds = metrics["models"]["recent_quantile_rule"]["rule_thresholds"]
    return {
        "requested_row_fractions": split["fractions_requested"],
        "actual_row_fractions": actual_row_fractions,
        "rows": {
            "train": split["train_rows"],
            "validation": split["validation_rows"],
            "test": split["test_rows"],
        },
        "decision_time_semantics": split.get(
            "decision_time_semantics",
            "Features use transactions dated on or before t0; the target begins on t0+1.",
        ),
        "boundary_audit": boundaries,
        "label_thresholds": {
            "basis": "Positive future quantity in the chronological training period.",
            "q25": label_definition["positive_future_qty_q25"],
            "q50": label_definition["positive_future_qty_q50"],
        },
        "recent_sales_baseline_thresholds": {
            "basis": "Historical sales_qty_28d in the chronological training period.",
            "q25": rule_thresholds["q25"],
            "q50": rule_thresholds["q50"],
        },
    }


def values_by_class(shap_values: Any) -> list[np.ndarray]:
    if isinstance(shap_values, list):
        return [np.asarray(values) for values in shap_values]
    values = np.asarray(shap_values)
    if values.ndim != 3:
        raise ValueError(f"Unexpected SHAP shape: {values.shape}")
    if values.shape[2] == len(CLASS_NAMES):
        return [values[:, :, index] for index in range(len(CLASS_NAMES))]
    if values.shape[1] == len(CLASS_NAMES):
        return [values[:, index, :] for index in range(len(CLASS_NAMES))]
    raise ValueError(f"Unexpected multiclass SHAP class axis: {values.shape}")


def shap_diagnostics(
    predictions: pd.DataFrame,
    snapshots: pd.DataFrame,
    split: dict[str, Any],
    metrics: dict[str, Any],
    diagnostics_dir: Path,
    samples_per_cutoff: int,
) -> dict[str, Any]:
    """Refit the selected deterministic LightGBM to assess explanation stability."""
    os.environ.setdefault("MPLCONFIGDIR", str(diagnostics_dir / "mpl-cache"))
    import shap

    snapshot_copy = snapshots.copy()
    snapshot_copy["cutoff_date"] = pd.to_datetime(snapshot_copy["cutoff_date"])
    train_dates = pd.to_datetime(split["train_cutoff_dates"])
    train = snapshot_copy.loc[snapshot_copy["cutoff_date"].isin(train_dates)]
    params = metrics["models"]["lightgbm"]["hyperparameters"]
    model = LGBMClassifier(
        objective="multiclass",
        num_class=len(CLASS_NAMES),
        n_estimators=params["n_estimators"],
        learning_rate=params["learning_rate"],
        num_leaves=params["num_leaves"],
        max_depth=-1,
        min_child_samples=params["min_child_samples"],
        subsample=0.9,
        colsample_bytree=0.9,
        reg_lambda=1.0,
        class_weight=params["class_weight"],
        random_state=params["random_state"],
        n_jobs=int(params.get("n_jobs", 4)),
        verbosity=-1,
    )
    model.fit(train[FEATURE_COLUMNS], train["risk_label"].astype(int))

    test_keys = predictions[["sku", "cutoff_date"]].copy()
    test_keys["cutoff_date"] = pd.to_datetime(test_keys["cutoff_date"])
    test = test_keys.merge(
        snapshot_copy,
        on=["sku", "cutoff_date"],
        validate="one_to_one",
    )
    refit_probability = model.predict_proba(test[FEATURE_COLUMNS])
    stored_probability = predictions[probability_columns("lightgbm")].to_numpy(dtype=float)
    max_probability_delta = float(np.abs(refit_probability - stored_probability).max())

    explainer = shap.TreeExplainer(model)
    stability_rows: list[dict[str, Any]] = []
    for cutoff_date, frame in test.groupby("cutoff_date", sort=True):
        sample = frame
        if len(sample) > samples_per_cutoff:
            sample = sample.sample(samples_per_cutoff, random_state=42)
        shap_values = values_by_class(explainer.shap_values(sample[FEATURE_COLUMNS]))
        mean_abs = np.mean([np.abs(values).mean(axis=0) for values in shap_values], axis=0)
        for feature, value in zip(FEATURE_COLUMNS, mean_abs):
            stability_rows.append(
                {
                    "cutoff_date": pd.Timestamp(cutoff_date).date().isoformat(),
                    "feature": feature,
                    "mean_abs_shap_mean": float(value),
                    "sample_rows": len(sample),
                }
            )
    stability = pd.DataFrame(stability_rows)
    stability.to_csv(diagnostics_dir / "shap_stability_by_cutoff.csv", index=False)

    importance = stability.pivot(
        index="feature", columns="cutoff_date", values="mean_abs_shap_mean"
    ).reindex(FEATURE_COLUMNS)
    rank_correlation = importance.rank(ascending=False).corr(method="spearman")
    rank_correlation.index.name = "cutoff_date"
    rank_correlation.to_csv(diagnostics_dir / "shap_stability_rank_correlation.csv")

    matched = predictions.copy()
    matched["cutoff_date"] = pd.to_datetime(matched["cutoff_date"])
    missed = matched.loc[
        matched["risk_label"].eq(0)
        & matched["lightgbm_prediction_name"].eq("LOW_RISK")
    ].copy()
    if missed.empty:
        local_payload: dict[str, Any] = {
            "status": "SKIPPED",
            "reason": "No actual CRITICAL case was predicted as LOW_RISK.",
        }
    else:
        selected = missed.sort_values("lightgbm_prob_LOW_RISK", ascending=False).iloc[0]
        local_frame = test.loc[
            (test["sku"].astype(str) == str(selected["sku"]))
            & (test["cutoff_date"] == selected["cutoff_date"])
        ]
        if len(local_frame) != 1:
            raise ValueError("Could not locate the selected missed-CRITICAL snapshot.")
        local_row = local_frame.iloc[0]
        local_values = values_by_class(explainer.shap_values(local_frame[FEATURE_COLUMNS]))
        local = pd.DataFrame(
            {
                "feature": FEATURE_COLUMNS,
                "feature_value": local_frame[FEATURE_COLUMNS].iloc[0].to_numpy(dtype=float),
                "shap_value_for_CRITICAL_raw_score": local_values[0][0],
            }
        )
        local["absolute_shap"] = local["shap_value_for_CRITICAL_raw_score"].abs()
        local["direction"] = np.where(
            local["shap_value_for_CRITICAL_raw_score"] > 0,
            "INCREASES_CRITICAL_RAW_SCORE",
            np.where(
                local["shap_value_for_CRITICAL_raw_score"] < 0,
                "DECREASES_CRITICAL_RAW_SCORE",
                "NEUTRAL",
            ),
        )
        local_payload = {
            "status": "COMPLETED",
            "method": "TreeSHAP for a refit deterministic multiclass LightGBM",
            "explained_class": "CRITICAL",
            "shap_output_scale": "LightGBM raw multiclass margin for the CRITICAL class",
            "case": {
                "sku": str(local_row["sku"]),
                "cutoff_date": local_row["cutoff_date"],
                "actual_class": "CRITICAL",
                "predicted_class": str(selected["lightgbm_prediction_name"]),
                "model_probabilities": {
                    name: float(selected[f"lightgbm_prob_{name}"])
                    for name in CLASS_NAMES
                },
                "future_qty_label_only": float(local_row["future_qty"]),
            },
            "top_feature_attributions": local.sort_values(
                "absolute_shap", ascending=False
            ).head(10).to_dict(orient="records"),
            "interpretation_boundary": (
                "These values explain the refit model's raw CRITICAL score for an "
                "error case. They do not establish the cause of future low sales."
            ),
        }
    write_json(diagnostics_dir / "shap_local_missed_critical_case.json", local_payload)
    return {
        "status": "COMPLETED",
        "samples_per_cutoff": samples_per_cutoff,
        "test_cutoffs": sorted(stability["cutoff_date"].unique().tolist()),
        "max_abs_probability_delta_vs_persisted_predictions": max_probability_delta,
        "local_missed_critical_case": local_payload["status"],
    }


def main() -> int:
    args = parse_args()
    experiment_dir = args.experiment_dir.resolve()
    selected_dir = experiment_dir / "selected"
    diagnostics_dir = experiment_dir / "diagnostics"
    diagnostics_dir.mkdir(parents=True, exist_ok=True)

    split = read_json(selected_dir / "temporal_split.json")
    label_definition = read_json(selected_dir / "label_definition.json")
    metrics = read_json(selected_dir / "metrics.json")
    predictions = pd.read_csv(selected_dir / "test_predictions.csv")
    snapshots = pd.read_parquet(selected_dir / "snapshots.parquet")
    model_names = list(metrics["models"])

    per_cutoff = per_cutoff_metrics(predictions, model_names)
    per_cutoff.to_csv(diagnostics_dir / "per_cutoff_metrics.csv", index=False)
    ranking = ranking_metrics(predictions, model_names)
    ranking.to_csv(diagnostics_dir / "ranking_metrics.csv", index=False)
    bootstrap = sku_cluster_bootstrap(
        predictions,
        repetitions=args.bootstrap_repetitions,
    )
    bootstrap.to_csv(diagnostics_dir / "sku_cluster_bootstrap_model_differences.csv", index=False)
    transitions = recent_zero_transition(predictions, snapshots)
    transitions.to_csv(diagnostics_dir / "recent_zero_transition.csv", index=False)
    boundary = boundary_exclusion_sensitivity(experiment_dir)
    boundary.to_csv(diagnostics_dir / "boundary_exclusion_sensitivity.csv", index=False)
    write_json(diagnostics_dir / "temporal_split_audit.json", split_audit(split, label_definition, metrics))
    shap_status = (
        {"status": "SKIPPED", "reason": "--skip-shap was requested."}
        if args.skip_shap
        else shap_diagnostics(
            predictions,
            snapshots,
            split,
            metrics,
            diagnostics_dir,
            args.shap_samples_per_cutoff,
        )
    )
    write_json(diagnostics_dir / "shap_diagnostics_status.json", shap_status)
    write_json(
        diagnostics_dir / "diagnostics_metadata.json",
        {
            "script": "scripts/analyze_nckh_multiclass_diagnostics.py",
            "run_at_utc": datetime.now(timezone.utc),
            "selected_horizon_days": 28,
            "ranking_protocol": {
                "positive_group": ["CRITICAL", "HIGH_RISK"],
                "score": "P(CRITICAL) + P(HIGH_RISK)",
                "pre_specified_shortlists": [100, "5% of selected test snapshots"],
                "tie_policy": "Stable input order for exact score ties.",
            },
            "paired_inference_protocol": {
                "method": "Paired nonparametric bootstrap of SKU clusters.",
                "repetitions": args.bootstrap_repetitions,
                "comparisons": "LightGBM against each baseline on the fixed selected test set.",
                "interpretation": (
                    "A 95% interval excluding zero supports a directional difference "
                    "under this retailer/test-period sample; it is not external validation."
                ),
            },
            "boundary_exclusion_protocol": (
                "Post-hoc robustness check that excludes the first cutoff of each "
                "saved validation/test partition when scoring. It does not refit a "
                "model or select a new horizon."
            ),
            "shap_status": shap_status,
        },
    )
    print(f"Wrote diagnostics to {diagnostics_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
