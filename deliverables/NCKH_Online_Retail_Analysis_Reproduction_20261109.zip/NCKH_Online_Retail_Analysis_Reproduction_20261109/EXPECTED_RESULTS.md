# Kết quả chuẩn để đối chiếu

Các giá trị sau là kết quả của run chuẩn dùng trong báo cáo. Chúng giúp
phát hiện việc chạy nhầm input, split hoặc cấu hình; không được dùng để
chọn lại mô hình sau khi nhìn test.

## Kiểm tra dữ liệu và split

| Hạng mục | Giá trị chuẩn |
| --- | ---: |
| Dòng giao dịch thô | 1.067.371 |
| Dòng giữ lại sau làm sạch | 1.003.714 |
| SKU giữ lại | 4.906 |
| SKU--cutoff hợp lệ, horizon 28 ngày | 63.675 |
| Train / validation / test | 42.089 / 10.482 / 11.104 |
| Horizon được chọn | 28 ngày |
| Ngưỡng Ground Truth Q25 / Q50 | 9 / 38 |

## Kết quả LightGBM chuẩn trên test 28 ngày

| Metric | Giá trị |
| --- | ---: |
| Macro-F1 | 0,5815 |
| Balanced Accuracy | 0,6051 |
| Recall nhóm CRITICAL + HIGH_RISK | 0,7935 |
| High-risk Average Precision | 0,8024 |

## So sánh baseline chuẩn

| Mô hình | Macro-F1 | Balanced Accuracy | Recall nhóm rủi ro cao | High-risk AP |
| --- | ---: | ---: | ---: | ---: |
| Recent-zero rule | 0,3064 | 0,3583 | 0,2602 | 0,4225 |
| Recent-sales quantile rule | 0,5731 | 0,5701 | 0,7253 | 0,5967 |
| Logistic Regression | 0,5517 | 0,5749 | 0,8133 | 0,7573 |
| Random Forest | 0,5838 | 0,5951 | 0,7780 | 0,7968 |
| LightGBM | 0,5815 | 0,6051 | 0,7935 | 0,8024 |

LightGBM là mô hình cân bằng và cạnh tranh; không được kết luận nó thắng
tuyệt đối vì Random Forest nhỉnh hơn về Macro-F1 và Logistic Regression
có recall nhóm rủi ro cao cao hơn.
