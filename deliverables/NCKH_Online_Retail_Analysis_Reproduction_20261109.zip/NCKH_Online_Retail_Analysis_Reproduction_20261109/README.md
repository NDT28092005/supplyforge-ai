# Gói tái lập toàn bộ thực nghiệm NCKH — Online Retail II

Gói này dùng để chạy lại toàn bộ phân tích từ workbook gốc đến artefact
đánh giá: làm sạch dữ liệu, snapshot theo thời gian, nhãn Ground Truth,
baseline, LightGBM, chọn horizon, SHAP, diagnostics, ablation và độ nhạy
Ground Truth. Đây là gói **tái lập thực nghiệm**, khác với ZIP prototype
DSS dùng để demo giao diện.

## Cấu trúc gói

| Thành phần | Vai trò |
| --- | --- |
| `data/online_retail_II.xlsx` | Workbook gốc Online Retail II. |
| `scripts/run_online_retail_nckh_multiclass.py` | Pipeline chính: làm sạch → feature → nhãn → train/test → SHAP. |
| `scripts/analyze_nckh_multiclass_diagnostics.py` | Cutoff stability, Precision@K, bootstrap, boundary sensitivity và SHAP diagnostics. |
| `scripts/run_nckh_robustness_experiments.py` | Ablation theo feature family và độ nhạy Ground Truth. |
| `RUN_FULL_ANALYSIS.sh` | Chạy toàn bộ pipeline trên Linux/macOS/WSL. |
| `RUN_FULL_ANALYSIS.ps1` | Chạy toàn bộ pipeline trên Windows PowerShell. |
| `EXPECTED_RESULTS.md` | Số liệu chuẩn để đối chiếu sau khi chạy. |

## Điều kiện cần

- Python 3.11 hoặc mới hơn.
- Bộ nhớ khả dụng tối thiểu khoảng 4 GB; thời gian chạy phụ thuộc máy vì
  pipeline huấn luyện 4 horizon, SHAP và bootstrap 500 lần lặp.
- Internet chỉ cần trong bước cài thư viện Python.

## Chạy toàn bộ trên Linux/macOS/WSL

```bash
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
PYTHON_BIN=.venv/bin/python bash RUN_FULL_ANALYSIS.sh
```

## Chạy toàn bộ trên Windows PowerShell

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\RUN_FULL_ANALYSIS.ps1 -Python .\.venv\Scripts\python.exe
```

## Thứ tự pipeline

1. Pipeline chính chạy horizon 14, 28, 30 và 60 ngày.
2. Horizon 28 được chọn bằng Macro-F1 trên validation; test không được
   dùng để chọn horizon hay ngưỡng nhãn.
3. Diagnostics đọc artefact đã lưu, không huấn luyện lại để chọn model.
4. Robustness chạy ablation và Ground Truth sensitivity tách riêng,
   không ghi đè `selected/`.

Output sẽ nằm tại:

```text
reports_NCKH/nckh_online_retail_multiclass/
├── horizon_014d/ ... horizon_060d/
├── selected/
├── diagnostics/
└── robustness/
```

Sau khi hoàn tất, mở `EXPECTED_RESULTS.md` để so sánh các số chính.
Sai khác nhỏ ở SHAP hoặc bootstrap có thể xảy ra nếu phiên bản thư viện
thay đổi; random state của các mô hình và bootstrap đều được cố định là 42.

## Ranh giới diễn giải

Target là rủi ro doanh số thấp trong tương lai từ dữ liệu giao dịch, không
phải tồn kho dư, lỗi thời, thiệt hại tài chính hoặc quan hệ nhân quả.
Các ngưỡng 9 và 38 chỉ có ý nghĩa tương đối với phân phối doanh số dương
của tập train trong Online Retail II.
