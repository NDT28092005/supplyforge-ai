#!/usr/bin/env bash
set -euo pipefail

analysis_python="${PYTHON_BIN:-python}"
report_dir="reports_NCKH/nckh_online_retail_multiclass"
export MPLCONFIGDIR="${MPLCONFIGDIR:-.mpl-cache}"
mkdir -p "$MPLCONFIGDIR"

echo "[1/3] Running the frozen-protocol multiclass experiment..."
"$analysis_python" scripts/run_online_retail_nckh_multiclass.py           --input data/online_retail_II.xlsx           --output-dir "$report_dir"           --horizons 14 28 30 60           --rf-estimators 100           --lgbm-estimators 150           --n-jobs 4

echo "[2/3] Running temporal, ranking and bootstrap diagnostics..."
"$analysis_python" scripts/analyze_nckh_multiclass_diagnostics.py           --experiment-dir "$report_dir"           --bootstrap-repetitions 500           --shap-samples-per-cutoff 400

echo "[3/3] Running feature ablation and Ground Truth sensitivity..."
"$analysis_python" scripts/run_nckh_robustness_experiments.py           --experiment-dir "$report_dir"           --n-jobs 4

echo "Complete. Read EXPECTED_RESULTS.md and inspect $report_dir"
