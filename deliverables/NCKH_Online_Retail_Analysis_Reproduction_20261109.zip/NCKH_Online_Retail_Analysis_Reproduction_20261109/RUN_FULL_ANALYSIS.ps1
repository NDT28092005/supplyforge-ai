param(
  [string]$Python = ".\.venv\Scripts\python.exe"
)

$ErrorActionPreference = "Stop"
$env:MPLCONFIGDIR = ".mpl-cache"
New-Item -ItemType Directory -Force -Path $env:MPLCONFIGDIR | Out-Null
$ReportDir = "reports_NCKH/nckh_online_retail_multiclass"

Write-Host "[1/3] Running the frozen-protocol multiclass experiment..."
& $Python scripts/run_online_retail_nckh_multiclass.py `
  --input data/online_retail_II.xlsx `
  --output-dir $ReportDir `
  --horizons 14 28 30 60 `
  --rf-estimators 100 `
  --lgbm-estimators 150 `
  --n-jobs 4

Write-Host "[2/3] Running temporal, ranking and bootstrap diagnostics..."
& $Python scripts/analyze_nckh_multiclass_diagnostics.py `
  --experiment-dir $ReportDir `
  --bootstrap-repetitions 500 `
  --shap-samples-per-cutoff 400

Write-Host "[3/3] Running feature ablation and Ground Truth sensitivity..."
& $Python scripts/run_nckh_robustness_experiments.py `
  --experiment-dir $ReportDir `
  --n-jobs 4

Write-Host "Complete. Read EXPECTED_RESULTS.md and inspect $ReportDir"
